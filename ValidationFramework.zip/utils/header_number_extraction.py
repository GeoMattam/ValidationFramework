from docx import Document

def extract_number_heading(doc_path: str):
    doc = Document(doc_path)
    heading_numbers = []
    heading_name = []

    for paragraph in doc.paragraphs:
        if paragraph.style.name.startswith('Heading'):    
            heading_numbers.append(paragraph.style.name.split()[1])
            heading_name.append(paragraph.text)
    
    heading_sections_result = []
    chapter = 1
    for i in range(len(heading_numbers)):
        if heading_numbers[i] == '1':
            heading_sections_result.append(str(chapter))
            chapter += 1
        else:
            if int(heading_numbers[i]) > int(heading_numbers[i-1]):
                if int(heading_numbers[i]) == 2:
                    heading_sections_result.append(heading_sections_result[-1] + '.1')
                else:
                    heading_sections_result.append(heading_sections_result[-1] + '.1' * (int(heading_numbers[i]) - 2))
            elif int(heading_numbers[i]) == int(heading_numbers[i-1]):
                u = heading_sections_result[-1].split('.')
                u[-1] = str(int(u[-1]) + 1)
                heading_sections_result.append('.'.join(u))
            elif int(heading_numbers[i]) < int(heading_numbers[i-1]):
                u = heading_sections_result[-1].split('.')
                u = u[:int(heading_numbers[i])]
                u[-1] = str(int(u[-1]) + 1)
                heading_sections_result.append('.'.join(u))
    
    total_heading = []
    for i in range(len(heading_numbers)):
        total_heading.append(heading_sections_result[i] + ' ' + heading_name[i])

    return total_heading

def filter_by_top_level(total_heading: list, top_level: str):
    return [heading for heading in total_heading if heading.startswith(top_level + ' ') or heading.startswith(top_level + '.')]

def filter_by_range(total_heading: list, start: str, end: str):
    result = []
    in_range = False
    for heading in total_heading:
        section_number = heading.split(' ')[0]
        if section_number == start:
            in_range = True
        if in_range:
            result.append(heading)
        if section_number == end:
            in_range = False
    return result

if __name__ == "__main__":
    doc_path = "C:/Solutions/ValidationFramework/includes/srs_validator/input/CQure_Insurance_SRS_Set1.docx"
    total_heading = extract_number_heading(doc_path)
    print("All headings for top-level 1:")
    print(filter_by_top_level(total_heading, '7'))
    print("\nHeadings between 3.5 and 3.6:")
    print(filter_by_range(total_heading, '3.5', '3.6'))