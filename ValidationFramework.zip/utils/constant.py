home_page =f"""<p>The fast-paced evolution of technology highlights the importance of agility, 
flexibility, and efficiency in software development for businesses. To drive this transformation, 
integrating Artificial Intelligence (AI) into software development is crucial, as it enhances operational
efficiency and accuracy. Furthermore, AI is seen as a groundbreaking solution to speed up innovative 
software deployments. A key area within AI, known as Generative AI (Gen AI),
plays a significant role in transforming the Software Development Lifecycle (SDLC). </p>

<p>According to research by Fortune Business Insights, the Global Gen AI market of 
SDLC is expected to grow from $341.3 million in 2023 to 2,833.9 million by 2030, 
displaying a CAGR of 35.3% during the 7-year forecast period. </p> """

main_home_page =f"""
---

# TCS A.S.C.E.N.D
**A**I **S**uite for **C**ognitive **E**ngineering **N**avigation and **D**elivery

---

TCS A.S.C.E.N.D is a cutting-edge **Generative AI-powered platform** that transforms the traditional Software Development Life Cycle (SDLC) into an intelligent, automated, and collaborative experience. Designed to support every major SDLC phase — from requirements to deployment and monitoring — TCS A.S.C.E.N.D brings speed, consistency, and quality to modern software engineering.

---

# 🔷  TCS A.S.C.E.N.D Tool Suite

A GenAI-powered set of solutions supporting each major phase of the Software Development Life Cycle (SDLC).

---

## 📄 DesignSage  
*Transforms Software Requirement Specifications (SRS) into structured High-Level Design (HLD) documents automatically.*  

---

## 🧠 LLDForge  
*Generates detailed Low-Level Design (LLD) from HLD and SRS, enabling precise architectural decomposition.*  

---

## 🧪 TestWeaver  
*Automatically creates functional test cases from SRS, ensuring traceability and early validation of business requirements.*  

---

## 🤖 CodeReflect  
*Acts as an intelligent AI coder and reviewer — generating code from design artifacts and iteratively improving it through structured feedback.*  

---

## 🚀 DeployMate
*Facilitates deployment-readiness by producing CI/CD-compatible artifacts and streamlining release automation.*  

---

## 📈 SystemPulse
*Monitors deployed systems with AI-driven insights, alerting, and operational feedback loops for continuous improvement.*  

---

## 🚀 Key Capabilities

### ✅ **End-to-End SDLC Coverage**
TCS A.S.C.E.N.D delivers modular GenAI solutions for every lifecycle phase:
- **Requirements** → Intelligent parsing and transformation into design artifacts
- **Design** → Auto-generation of HLD and LLD from SRS
- **Build** → Code generation from HLD/LLD
- **Testing** → Creation of unit tests, functional test cases from specs
- **Deployment** → CI/CD integration-ready outputs
- **Monitoring** *(upcoming)* → AI-driven incident detection and feedback loops

---

## 🤖 Intelligent Agent Architecture
Each module is powered by **context-aware GenAI agents**, trained to:
- Understand phase-specific needs and constraints
- Generate artifacts aligned with architecture and domain
- Enable seamless handoffs across Dev, QA, and Ops

---

## ⚙️ Benefits

- **Accelerated Delivery**: Automates repetitive engineering tasks and reduces cycle time
- **Enhanced Quality**: Ensures alignment between requirements, code, and test
- **Cost Efficiency**: Lowers manual effort across design, development, and validation
- **Modular & Scalable**: Adopt individually or deploy as a unified SDLC automation suite

---

## 💡 Why TCS A.S.C.E.N.D?

> **TCS A.S.C.E.N.D** is more than a tool — it’s an AI-native co-engineer that supports your team across the entire SDLC.  
> From design blueprints to test automation and future-ready deployment flows, TCS A.S.C.E.N.D is built to **forge the future of intelligent software delivery**.

---

"""

hld_home_page_main=f"""
# 🔷 TCS A.S.C.E.N.D : DesignSage 
**GenAI-Powered High-Level Design Generator**

---

**DesignSage** is an AI-driven solution developed under the **TCS A.S.C.E.N.D** platform, purpose-built to automate the creation of **High-Level Design (HLD)** documents directly from **Software Requirement Specifications (SRS)**. It transforms how design artifacts are produced in the early stages of software engineering, enabling faster, more accurate, and standards-compliant architecture documentation.

---

## 🚀 Key Capabilities

- **Automated HLD Generation**  
  Converts business and functional requirements into structured, componentized High-Level Designs with minimal manual intervention.

- **Architecture-Aware Intelligence**  
  Leverages GenAI models trained on architectural patterns, component models, and domain-specific best practices to ensure design quality and relevance.

- **Traceability from Requirements**  
  Maintains traceable links between SRS elements and corresponding HLD components, ensuring alignment with business objectives.

- **Standardized Output**  
  Produces design documents in pre-approved formats that align with enterprise architecture standards, reducing rework and review cycles.

---

## 🎯 Benefits

- **Accelerates Design Phase**: Cuts down manual design time by up to 70%  
- **Improves Design Consistency**: Enforces reusable patterns and frameworks  
- **Enhances Collaboration**: Provides a shared, AI-generated design baseline for architects, developers, and QA teams  
- **Reduces Errors Early**: Detects potential design gaps during transformation from SRS to HLD

---

## 💡 Built for Modern Engineering

As part of the **TCS A.S.C.E.N.D** suite, **DesignSage** helps teams move swiftly and intelligently from **requirements to architecture**. It is ideal for greenfield projects, architecture-heavy builds, or any engineering team looking to streamline the upfront design process using Generative AI.

---
"""
hld_home_page=f"""<p>
Automation, powered by tools like LangGraph, enhances the HLD creation process by simplifying workflows, 
reducing errors, and improving collaboration. Here’s how this transformative approach functions:

<div class='subheading'>🛠️ Key Benefits of Automation</div>

<span class='subheading'>Speed Up the Design Process:</span>AI agents quickly generate drafts and revisions, enabling faster iterations and shortening project timelines.
<b>Maintain Consistency:</b> Structured methodologies ensure consistent definitions of components and interactions, minimizing errors and discrepancies in the designs.
<b>Facilitate Quick Revisions:</b> AI-driven feedback loops allow for efficient updates, ensuring designs stay aligned with evolving requirements.
<b>Reduce Human Effort:</b> By automating repetitive tasks, AI frees up users and stakeholders to focus on key decision-making and final reviews, cutting down on manual work.
<b>HLD Tasks Suitable for Automation</b>

<b>Architecture Recommendations:</b> AI agents analyze past projects or predefined templates to propose the best system architectures.

<b>Component Breakdown:</b> Automatically generate detailed descriptions of each component’s functionality, inputs, and outputs based on specified requirements.
<b>Data Flow Mapping:</b> Agents produce accurate data flow diagrams that match the defined system components.
<b>Technology Recommendations:</b> Provide customized suggestions for the most appropriate technologies for each component, based on constraints and architecture.
<b>Integration Specifications:</b> Automatically document integration points with third-party systems or existing infrastructures.
</p>"""


testcases_home_page=f"""<p>
Test case generation is the process of creating a set of conditions, inputs, and expected results to validate whether a system or application behaves as expected under various conditions. The purpose of generating test cases is to ensure that the software is thoroughly tested and can handle edge cases, user interactions, and other scenarios that may arise in real-world usage. It is a critical part of software testing, which helps identify bugs, defects, or issues before the software is released.
</p>
<p>
Before generating test cases, testers must understand the requirements and functionality of the software. This includes the features, user stories, or technical specifications provided by the development team.
</p>
<p>
Test cases should map to the system’s requirements and functionality to ensure all scenarios are covered.
</p>
"""

testcases_home_page_main =f"""
# 🔷 TCS A.S.C.E.N.D : TestWeaver
**GenAI-Powered Functional Test Case Generator**

---

**TestWeaver** is an intelligent, GenAI-powered solution within the **TCS A.S.C.E.N.D** suite, designed to automate the generation of **Functional Test Cases** directly from **Software Requirement Specifications (SRS)**. It enables QA teams and developers to accelerate test planning while ensuring full alignment with business requirements and functional intent.

By transforming static SRS documents into executable test artifacts, **TestWeaver** brings agility, precision, and traceability into the testing phase — reducing manual effort and improving test coverage.

---

## 🚀 Key Capabilities

- **SRS-to-Test Case Transformation**  
  Automatically interprets functional requirements and generates structured test cases, scenarios, and acceptance criteria.

- **Domain-Aware AI Models**  
  Uses pretrained and fine-tuned LLMs familiar with various industry verticals and SDLC patterns to contextualize test logic.

- **Traceability & Coverage Mapping**  
  Maintains links between each test case and corresponding SRS item, enabling gap analysis and audit readiness.

- **Customizable Test Formats**  
  Generates output in standard test formats (e.g., Gherkin, tabular, user story acceptance) suitable for integration into test management tools.

---

## 🎯 Benefits

- **Accelerates QA Planning**: Reduces test case creation time by up to 60%  
- **Improves Test Accuracy**: Minimizes human misinterpretation of requirements  
- **Enhances Coverage**: Detects missing logic and untested edge cases  
- **Bridges Dev-QA Gap**: Provides a shared understanding of functionality across teams

---

## 💡 Built for Quality at Speed

As a core module in the **TCS A.S.C.E.N.D** platform, **TestWeaver** helps engineering teams move seamlessly from **requirements to ready-to-execute tests**, ensuring quality is embedded early — and intelligently — in the software delivery lifecycle.

---
"""

fs_home_page=f"""<p>
A functional specification document (FSD) is a formal document that details the intended capabilities, appearance, and user interactions of a product, serving as a guideline for developers during software development, ensuring everyone understands what the system should do
</p>
"""


code_home_page=f"""<p>
Generative AI (GenAI) tools and techniques to assist in software development, including tasks like code generation, code completion, bug detection, and code translation. 
</p>
<p>
Benefits of GenAI in Code
Increased Productivity: Automating repetitive tasks and accelerating the development process.
Improved Code Quality: Identifying bugs and vulnerabilities early on.
Faster Development Cycles: Streamlining the software development lifecycle.
Reduced Cognitive Load: Helping developers focus on more complex tasks.
Enhanced Collaboration: Facilitating code review and collaboration among developers.
Easier Code Maintenance: Simplifying the process of updating and maintaining code. 
</p>
"""

codereview_home_page=f"""<p>
The integration of Generative AI (GenAI) into the realm of code reviews represents 
a significant leap forward from traditional automated methods. Unlike conventional AI, 
which typically focuses on identifying patterns or anomalies based on predefined rules,
GenAI introduces a level of creativity and adaptability that was previously unattainable.
</p>
"""

coderefactoring_home_page_main=f"""
# 🔷 TCS A.S.C.E.N.D : CodeReflect
**GenAI-Powered Collaborative Code Reviewer & Generator**

---

**CodeReflect** is a GenAI-driven solution developed under the **TCS A.S.C.E.N.D** platform, designed to act as a **collaborative AI coder and reviewer** embedded directly into the Software Development Life Cycle (SDLC). It transforms traditional development workflows by introducing an intelligent **review-and-reflect loop**, enabling teams to build cleaner, more consistent, and production-ready code with greater efficiency.

---

## 🚀 Key Capabilities

- **AI-Driven Code Review**  
  Automatically reviews submitted code for functionality, readability, maintainability, and adherence to best practices.

- **Context-Aware Code Suggestions**  
  Provides intelligent, line-by-line improvements grounded in the project’s architecture and coding standards.

- **Review-and-Reflect Pattern**  
  Powered by specialized agents that iteratively **analyze**, **critique**, and **refactor** code until optimal output is achieved.

- **Collaborative Feedback Loop**  
  Developers receive structured feedback, inline suggestions, and automated fixes — enhancing code quality and team learning.

---

## 🎯 Benefits

- **Improves Code Quality**: Enforces consistency, removes anti-patterns, and enhances readability  
- **Accelerates Review Cycles**: Reduces manual review load and speeds up approvals  
- **Enhances Developer Productivity**: Serves as an AI pair programmer and quality gatekeeper  
- **Supports Continuous Improvement**: Learns over time and adapts to team-specific coding styles

---

## 💡 Built for AI-Augmented Engineering

As a powerful module of the **TCS A.S.C.E.N.D** suite, **CodeReflect** seamlessly integrates into modern DevOps pipelines and IDEs. It empowers development teams with an intelligent, always-on code companion — accelerating delivery while upholding engineering excellence across the SDLC.

---
"""
coderefactoring_home_page=f"""<p>
Refactoring is the process of restructuring code, while not changing its original functionality.
The goal of refactoring is to improve internal code by making many small changes without altering the 
code's external behavior.
</p>
<p>
Code refactoring using an LLM refers to using an AI model to automatically 
improve the internal structure of code without changing its external behavior.

Refactoring is about cleaning up code to make it more:

1. Readable
2. Maintainable
3. Efficient
4. Aligned with best practices
</p>
"""


lld_home_page = f"""
<p>
Generating Low Level Design (LLD) Using Generative AI
Low Level Design (LLD) defines the detailed internal structure of each software module, including class diagrams, method signatures, database interactions, and business logic flow. Traditionally a time-consuming task, LLD generation can be significantly accelerated using Generative AI (GenAI).

By leveraging Large Language Models (LLMs), GenAI can analyze high-level inputs such as Business Requirement Documents (BRDs), System Requirements Specifications (SRS), or High-Level Design (HLD) to automatically produce comprehensive LLD artifacts.

🔍 Key Capabilities of GenAI for LLD:
Class and interface definitions based on entity relationships and service responsibilities
Method stubs and internal logic flows derived from use case narratives
Component and package diagrams in text-based formats like PlantUML
REST API specifications, including input/output models
Database table mappings and ORM model suggestions

⚙️ How It Works:
Input Ingestion: GenAI ingests SRS/HLD documents using structured prompts or document parsers.
Contextual Understanding: The LLM interprets modules, responsibilities, and dependencies.
Code and Diagram Generation: It generates detailed design outputs like class diagrams, service layers, pseudocode, and database schemas.
Review & Refinement: Human developers review and fine-tune the generated LLD to ensure alignment with architecture and standards.

🎯 Benefits:
Speeds up design phase by reducing manual effort
Ensures consistency with upstream documentation
Improves traceability from requirements to design
Enables collaborative refinement through conversational interfaces

Generative AI transforms LLD creation from a purely manual process to a semi-automated, interactive engineering task, enabling faster and more scalable software design.
</p>
"""