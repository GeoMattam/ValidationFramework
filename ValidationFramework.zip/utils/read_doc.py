from docx import Document
import re

# Load document
doc = Document("C:/Solutions/ValidationFramework/includes/srs_validator/input/CQure_Insurance_SRS_Set1.docx")

sections = {}
current_section = None

# Regex for section numbers like 3.1, 3.1.2, etc.
section_pattern = re.compile(r'^/d+(/./d+)*')

for para in doc.paragraphs:
    text = para.text.strip()
    if not text:
        continue
    
    if section_pattern.match(text):
        current_section = section_pattern.match(text).group()
        sections[current_section] = text
    elif current_section:
        sections[current_section] += "/n" + text

# Print all sections
for sec, content in sections.items():
    print(f"Section {sec}:")
    print(content)
    print("-" * 50)