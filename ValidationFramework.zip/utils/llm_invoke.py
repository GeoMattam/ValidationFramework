import os
from dotenv import load_dotenv
#from langchain_google_genai import ChatGoogleGenerativeAI
#from langchain_google_genai import GoogleGenerativeAI
#from langchain_openai import ChatOpenAI
#from langchain_ollama.llms import OllamaLLM
#import google.generativeai as genai
from pydantic import BaseModel
from openai import OpenAI

from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages

# load .env file to environment
load_dotenv()

MODEL_INSTANCE = os.getenv('MODEL_INSTANCE')
MODEL_NAME = os.getenv('MODEL_NAME')
ROOT_PATH =  os.getenv('ROOT_PATH')

def llm_initialize(framework):
    client =None

    match framework:
        case "Gemini":
            API_KEY = os.getenv('GEMINI_API_KEY')
            client = OpenAI(base_url="https://generativelanguage.googleapis.com/v1beta/openai/", api_key=API_KEY)
        # case "OpenAI":
        #     API_KEY = os.getenv('OPEN_API_KEY')
        #     MODEL_NAME = os.getenv('MODEL_NAME')
        #     client = ChatOpenAI(model=MODEL_NAME, temperature=0, max_retries=1)

        # case "Ollama":
        #     API_KEY = os.getenv('OPEN_API_KEY')
        #     MODEL_NAME = os.getenv('MODEL_NAME')
        #     client = OllamaLLM(model="bakllava")
    
    return client

def call_llm_model(client,messages):
    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages)

    return response

def llm_execution(prompt):
    
    messages = [
        {"role": "system", "content": "You are an expert Business Analyst and System Architect."},
        {"role": "user", "content": prompt}
    ]

    # Initialize LLM client
    llm_client = llm_initialize(MODEL_INSTANCE)
    
    # Invoke LLM
    response = llm_client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages
    )
    
    # Extract content from LLM response
    response_content = response.choices[0].message.content.strip()
    
    return response_content