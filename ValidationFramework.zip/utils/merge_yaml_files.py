import os
import yaml
import re
from pathlib import Path
from typing import Dict, List

def extract_number(id_str: str) -> int:
    if not id_str or not isinstance(id_str, str):
        print(f"Invalid ID: {id_str} (empty or not a string)")
        return 0
    match = re.search(r'\d+', id_str)
    return int(match.group()) if match else 0

def generate_id(prefix: str, number: int) -> str:
    return f"{prefix}{number:03d}"

def preprocess_yaml_file(file_path: str) -> bool:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        cleaned_lines = []
        in_multiline = False
        indent_level = 0
        in_sequence = False
        sequence_indent = 0
        for i, line in enumerate(lines, 1):
            stripped_line = line.strip()
            if not stripped_line or stripped_line.startswith('#'):
                cleaned_lines.append(line.rstrip('\n'))
                continue

            # Detect start of sequence
            if stripped_line.startswith('- '):
                in_sequence = True
                sequence_indent = len(line) - len(line.lstrip())
                indent_level = sequence_indent + 2  # Expected indent for fields
                cleaned_lines.append(line.rstrip('\n'))
                continue

            # Detect start of multi-line string
            if stripped_line.endswith(': |') or stripped_line.endswith(': >'):
                in_multiline = True
                indent_level = len(line) - len(line.lstrip())
                cleaned_lines.append(line.rstrip('\n'))
                continue

            # Handle multi-line continuation
            if in_multiline:
                if not line.startswith(' ' * (indent_level + 2)):
                    in_multiline = False
                cleaned_lines.append(line.rstrip('\n'))
                continue

            # Handle fields with potential issues
            if ': ' in line and not (stripped_line.endswith(':') or stripped_line.endswith(': |') or stripped_line.endswith(': >')):
                key, value = line.split(': ', 1)
                indent = len(key) - len(key.lstrip())
                value = value.strip()
                # Handle quoted strings with trailing text or problematic characters
                if (value.startswith('"') or value.startswith("'")) and ('.' in value or ':' in value):
                    # Extract quoted part and trailing text
                    quote_char = value[0]
                    end_quote = value.find(quote_char, 1)
                    if end_quote != -1:
                        quoted_part = value[:end_quote + 1]
                        trailing = value[end_quote + 1:].strip()
                        if trailing:
                            cleaned_lines.append(f"{key.rstrip()}: |")
                            cleaned_lines.append(f"{' ' * (indent + 2)}{quoted_part} {trailing}")
                        else:
                            cleaned_lines.append(line.rstrip('\n'))
                    else:
                        cleaned_lines.append(f"{key.rstrip()}: |")
                        cleaned_lines.append(f"{' ' * (indent + 2)}{value}")
                # Handle unquoted values with colons
                elif ':' in value and not (value.startswith('"') or value.startswith("'")):
                    cleaned_lines.append(f"{key.rstrip()}: |")
                    cleaned_lines.append(f"{' ' * (indent + 2)}{value}")
                else:
                    cleaned_lines.append(line.rstrip('\n'))
            else:
                cleaned_lines.append(line.rstrip('\n'))

            # Reset sequence if indentation decreases
            if in_sequence and line.strip() and not line.startswith(' ' * indent_level):
                in_sequence = False

        # Write the preprocessed file
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(cleaned_lines) + '\n')
        print(f"Preprocessed {file_path}")
        return True
    except Exception as e:
        print(f"Error preprocessing {file_path}: {str(e)}")
        return False

def clean_yaml_content(content: str) -> str:
    if content.startswith("```yaml"):
        content = content[7:].strip()
    if content.endswith("```"):
        content = content[:-3].strip()
    if content.startswith("---"):
        content = content[3:].strip()
    if content.endswith("---"):
        content = content[:-3].strip()

    lines = content.splitlines()
    cleaned_lines = []
    in_multiline = False
    indent_level = 0
    in_sequence = False
    sequence_indent = 0
    for line in lines:
        stripped_line = line.strip()
        if stripped_line.startswith('- '):
            in_sequence = True
            sequence_indent = len(line) - len(line.lstrip())
            indent_level = sequence_indent + 2
            cleaned_lines.append(line)
            continue
        if stripped_line.endswith(': |') or stripped_line.endswith(': >'):
            in_multiline = True
            indent_level = len(line) - len(line.lstrip())
            cleaned_lines.append(line)
            continue
        if in_multiline:
            if not line.strip().startswith('  '):
                in_multiline = False
            cleaned_lines.append(line)
            continue
        if ': ' in line and not (stripped_line.endswith(':') or stripped_line.endswith(': |') or stripped_line.endswith(': >')):
            key, value = line.split(': ', 1)
            indent = len(key) - len(key.lstrip())
            value = value.strip()
            if (value.startswith('"') or value.startswith("'")) and ('.' in value or ':' in value):
                quote_char = value[0]
                end_quote = value.find(quote_char, 1)
                if end_quote != -1:
                    quoted_part = value[:end_quote + 1]
                    trailing = value[end_quote + 1:].strip()
                    if trailing:
                        cleaned_lines.append(f"{key.rstrip()}: |")
                        cleaned_lines.append(f"{' ' * (indent + 2)}{quoted_part} {trailing}")
                    else:
                        cleaned_lines.append(line)
                else:
                    cleaned_lines.append(f"{key.rstrip()}: |")
                    cleaned_lines.append(f"{' ' * (indent + 2)}{value}")
            elif ':' in value and not (value.startswith('"') or value.startswith("'")):
                cleaned_lines.append(f"{key.rstrip()}: |")
                cleaned_lines.append(f"{' ' * (indent + 2)}{value}")
            else:
                cleaned_lines.append(line)
        else:
            cleaned_lines.append(line)
        if in_sequence and line.strip() and not line.startswith(' ' * indent_level):
            in_sequence = False

    return "\n".join(cleaned_lines)

def clean_string_field(value: str) -> str:
    if isinstance(value, str):
        return value.strip().replace('\n\n', '\n').replace('\r\n', '\n').strip("'").strip('"')
    return value

def merge_yaml_files(input_folder: str, output_file: str) -> None:
    output_dir = os.path.dirname(output_file)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    merged_data = {
        "Functional_Requirements": [],
        "Non_Functional_Requirements": [],
        "Business_Rules": [],
        "Ambiguous_or_Subjective_Requirements": [],
        "Other_Observations": []
    }

    last_ids = {
        "FR": 0,  # Functional Requirements
        "NFR": 0,  # Non-Functional Requirements
        "BR": 0,   # Business Rules
        "AR": 0,    # Ambiguous or Subjective Requirements
        "OBS": 0   # Other Observations
    }

    prefix_mapping = {
        "Functional_Requirements": "FR",
        "Non_Functional_Requirements": "NFR",
        "Business_Rules": "BR",
        "Ambiguous_or_Subjective_Requirements": "AR",
        "Other_Observations": "OBS"
    }

    input_path = Path(input_folder)
    yaml_files = [f for f in input_path.glob("*.yaml") if f.name != 'merged_requirements.yaml']
    if not yaml_files:
        print(f"No YAML files found in {input_folder}")
        return

    yaml_files = sorted(yaml_files, key=lambda x: x.stat().st_mtime)

    all_items = {category: [] for category in merged_data.keys()}
    for file_path in yaml_files:
        print(f"\nProcessing file: {file_path}")
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            content = clean_yaml_content(content)
            
            try:
                data = yaml.safe_load(content)
                if not data or not isinstance(data, dict):
                    print(f"Warning: Empty or invalid YAML in {file_path}: {data}")
                    continue
            except yaml.YAMLError as e:
                print(f"Error parsing YAML in {file_path}: {str(e)}")
                if preprocess_yaml_file(file_path):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = clean_yaml_content(f.read())
                    try:
                        data = yaml.safe_load(content)
                    except yaml.YAMLError as e:
                        print(f"Retry failed for {file_path}: {str(e)}")
                        with open(file_path, 'r', encoding='utf-8') as f:
                            lines = f.readlines()
                        error_line = int(str(e).split('line ')[-1].split(',')[0])
                        start = max(1, error_line - 2)
                        end = min(len(lines), error_line + 3)
                        print(f"Context around line {error_line}:")
                        for i, line in enumerate(lines[start-1:end], start):
                            print(f"Line {i}: {line.rstrip()}")
                        continue
                else:
                    continue
            
            # Initialize empty categories if not present
            for category in merged_data.keys():
                if category not in data:
                    data[category] = []
                    print(f"Initialized empty category {category} for {file_path}")

            # Print counts for each category in the current file
            print(f"Counts for {file_path.name}:")
            for category in merged_data.keys():
                item_count = len(data[category]) if isinstance(data[category], list) else 0
                print(f"  {category}: {item_count}")

            for category in merged_data.keys():
                items = data[category]
                if not isinstance(items, list):
                    print(f"Warning: {category} in {file_path} is not a list: {items}")
                    continue

                id_field = "observation_id" if category == "Other_Observations" else "requirement_id"
                expected_prefix = prefix_mapping[category]

                for i, item in enumerate(items, 1):
                    try:
                        if not isinstance(item, dict):
                            print(f"Warning: Invalid item in {category} from {file_path}: {item}")
                            continue
                        if id_field not in item:
                            print(f"Warning: Missing {id_field} in item from {file_path}: {item}")
                            continue

                        current_id = item[id_field]
                        if not isinstance(current_id, str):
                            print(f"Warning: Invalid {id_field} type in {file_path}: {current_id} (item: {item})")
                            continue

                        if 'original_text' in item and item['original_text'] is None:
                            print(f"Skipping item in {category} from {file_path} due to null original_text: {item}")
                            continue

                        prefix_length = 3 if expected_prefix in ("NFR", "OBS") else 2 if expected_prefix in ("FR", "BR", "AR") else 1
                        prefix = current_id[:prefix_length]
                        if prefix != expected_prefix:
                            print(f"Warning: ID prefix mismatch in {file_path}: expected {expected_prefix}, got {prefix} for {current_id} (item: {item})")
                            continue

                        # Clean string fields in item
                        cleaned_item = {k: clean_string_field(v) if isinstance(v, str) else v for k, v in item.items()}
                        all_items[category].append(cleaned_item)
                        current_number = extract_number(current_id)
                        last_ids[prefix] = max(last_ids[prefix], current_number)

                    except Exception as e:
                        print(f"Error processing item {i} in {category} from {file_path}: {str(e)} (item: {item})")
                        continue

        except Exception as e:
            print(f"Unexpected error processing {file_path}: {str(e)}")
            continue
        
    for category in merged_data.keys():
        print(f"\nRenumbering {category}")
        id_field = "observation_id" if category == "Other_Observations" else "requirement_id"
        prefix = prefix_mapping[category]
        last_ids[prefix] = 0  # Reset to start at 001

        for i, item in enumerate(all_items[category], 1):
            try:
                if not isinstance(item, dict) or id_field not in item:
                    print(f"Warning: Skipping invalid item {i} in {category}: {item}")
                    continue

                current_id = item[id_field]
                if not isinstance(current_id, str):
                    print(f"Warning: Skipping item {i} with invalid {id_field} type: {current_id} (item: {item})")
                    continue

                if 'original_text' in item and item['original_text'] is None:
                    print(f"Skipping item in {category} due to null original_text: {item}")
                    continue

                prefix_length = 3 if prefix in ("NFR", "OBS") else 2 if prefix in ("FR", "BR", "AR") else 1
                item_prefix = current_id[:prefix_length]
                if item_prefix != prefix:
                    print(f"Warning: ID prefix mismatch: expected {prefix}, got {item_prefix} for {current_id} (item: {item})")
                    continue

                last_ids[prefix] += 1
                new_item = {k: clean_string_field(v) if isinstance(v, str) else v for k, v in item.copy().items()}
                new_item[id_field] = generate_id(prefix, last_ids[prefix])
                
                if 'original_text' in new_item:
                    original_text = new_item['original_text']
                    if isinstance(original_text, str) and len(original_text) > 1000:
                        print(f"Warning: Large original_text in {category} for {new_item[id_field]}: {original_text[:100]}...")
                    elif not isinstance(original_text, str):
                        print(f"Warning: Invalid original_text type in {category} for {new_item[id_field]}: {original_text}")
                
                merged_data[category].append(new_item)

            except Exception as e:
                print(f"Error renumbering item {i} in {category}: {str(e)} (item: {item})")
                continue

    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            yaml.dump(merged_data, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=1000)
        print(f"\nSuccessfully merged {len(yaml_files)} files into {output_file}")
        print(f"Functional Requirements: {len(merged_data['Functional_Requirements'])}")
        print(f"Non-Functional Requirements: {len(merged_data['Non_Functional_Requirements'])}")
        print(f"Business Rules: {len(merged_data['Business_Rules'])}")
        print(f"Ambiguous or Subjective Requirements: {len(merged_data['Ambiguous_or_Subjective_Requirements'])}")
        print(f"Other Observations: {len(merged_data['Other_Observations'])}")
    except Exception as e:
        print(f"Error writing to {output_file}: {str(e)}")

if __name__ == "__main__":
    input_folder = r"C:\Solutions\ValidationFramework\includes\srs_validator\output\f8bc9ab4-7828-41a0-bace-988dae8e0607"
    output_file = r"C:\Solutions\ValidationFramework\includes\srs_validator\output\f8bc9ab4-7828-41a0-bace-988dae8e0607\merged_requirements.yaml"
    merge_yaml_files(input_folder, output_file)