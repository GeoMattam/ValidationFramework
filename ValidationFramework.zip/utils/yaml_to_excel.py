import yaml
import pandas as pd
import unicodedata

# Function to normalize special characters
def normalize_text(text):
    if not isinstance(text, str):
        return text
    # Replace specific Unicode characters with ASCII equivalents
    replacements = {
        '\u1F86A': '->',  # 🡪 (RIGHTWARDS ARROW WITH LARGE TRIANGLE ARROWHEAD)
        '\u2018': "'",    # Left single quotation mark
        '\u2019': "'",    # Right single quotation mark
        '\u201C': '"',    # Left double quotation mark
        '\u201D': '"',    # Right double quotation mark
    }
    for unicode_char, ascii_char in replacements.items():
        text = text.replace(unicode_char, ascii_char)
    # Normalize other Unicode characters to their closest ASCII representation
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
    return text

def flatten_to_dataframe(items, section_name):
    if not items:
        return pd.DataFrame()
    
    flat_data = []
    
    for item in items:
        flat_item = {}
        flat_item['section'] = section_name
        
        for key, value in item.items():
            if isinstance(value, list):
                # Apply normalization to each element in the list
                normalized_list = [normalize_text(str(v)) if isinstance(v, str) else v for v in value]
                flat_item[key] = '; '.join(str(v) for v in normalized_list) if normalized_list else ''
            else:
                # Apply normalization to scalar values
                flat_item[key] = normalize_text(value) if isinstance(value, str) else value
        flat_data.append(flat_item)
    
    return pd.DataFrame(flat_data)

# File paths
file_path = r'C:\Solutions\ValidationFramework\includes\srs_validator\output\f8bc9ab4-7828-41a0-bace-988dae8e0607\merged_requirements.yaml'
output_file_path = r'C:\Solutions\ValidationFramework\includes\srs_validator\output\f8bc9ab4-7828-41a0-bace-988dae8e0607\requirements.xlsx'

# Read YAML file with UTF-8 encoding
with open(file_path, 'r', encoding='utf-8') as file:
    data = yaml.safe_load(file)

# Define sections
sections = {
    'Functional_Requirements': data.get('Functional_Requirements', []),
    'Non_Functional_Requirements': data.get('Non_Functional_Requirements', []),
    'Business_Rules': data.get('Business_Rules', []),
    'Ambiguous_or_Subjective_Requirements': data.get('Ambiguous_or_Subjective_Requirements', []),
    'Other_Observations': data.get('Other_Observations', [])
}

# Write to Excel using openpyxl
with pd.ExcelWriter(output_file_path, engine='openpyxl') as writer:
    for section_name, items in sections.items():
        df = flatten_to_dataframe(items, section_name)
        if not df.empty:
            df.to_excel(writer, sheet_name=section_name[:31], index=False)

print(f"Excel file 'requirements.xlsx' has been created successfully at {output_file_path}.")