import yaml
from docx import Document
import csv
import os

def extract_number_heading(doc_path: str):
    doc = Document(doc_path)
    heading_numbers = []
    heading_name = []
    heading_sections_result = []

    for paragraph in doc.paragraphs:
        if paragraph.style.name.startswith('Heading'):
            try:
                heading_level = int(paragraph.style.name.split()[1])
                heading_numbers.append(heading_level)
                heading_name.append(paragraph.text.strip())
            except (IndexError, ValueError):
                print(f"Warning: Invalid heading style format for paragraph: {paragraph.text}")
                continue

    chapter = 1
    for i in range(len(heading_numbers)):
        current_level = heading_numbers[i]
        if current_level == 1:
            heading_sections_result.append(str(chapter))
            chapter += 1
        else:
            if i == 0:
                heading_sections_result.append(f"{chapter}.{1 * (current_level - 1)}")
            elif current_level > heading_numbers[i-1]:
                if current_level == 2:
                    heading_sections_result.append(f"{heading_sections_result[-1]}.1")
                else:
                    base_section = str(heading_sections_result[-1])
                    heading_sections_result.append(f"{base_section}.{1 * (current_level - 2)}")
            elif current_level == heading_numbers[i-1]:
                u = heading_sections_result[-1].split('.')
                u[-1] = str(int(u[-1]) + 1)
                heading_sections_result.append('.'.join(u))
            elif current_level < heading_numbers[i-1]:
                u = heading_sections_result[-1].split('.')
                u = u[:current_level]
                u[-1] = str(int(u[-1]) + 1)
                heading_sections_result.append('.'.join(u))

    total_heading = [(section, name) for section, name in zip(heading_sections_result, heading_name)]
    return total_heading

def load_yaml(yaml_path: str):
    try:
        with open(yaml_path, 'r') as file:
            data = yaml.safe_load(file)
        return data
    except yaml.YAMLError as e:
        print(f"Error parsing YAML file: {e}")
        return None

def compare_sections(doc_path: str, yaml_path: str):
    try:
        doc_sections = extract_number_heading(doc_path)
    except Exception as e:
        print(f"Error extracting sections from DOCX: {e}")
        return None

    doc_section_numbers = {section[0] for section in doc_sections if '.' not in section[0]}
    doc_subsection_numbers = {section[0] for section in doc_sections if '.' in section[0]}
    doc_section_map = {section[0]: section[1] for section in doc_sections}

    yaml_data = load_yaml(yaml_path)
    if not yaml_data:
        return None

    yaml_sections = set()
    yaml_subsections = set()
    for category in ['Functional_Requirements', 'Non_Functional_Requirements', 'Business_Rules', 'Ambiguous_or_Subjective_Requirements', 'Other_Observations']:
        if category in yaml_data and isinstance(yaml_data[category], list):
            for req in yaml_data[category]:
                if req.get('source_section') and req['source_section'] != 'null':
                    yaml_sections.add(str(req['source_section']))
                if req.get('source_sub_section') and req['source_sub_section'] != 'null':
                    yaml_subsections.add(str(req['source_sub_section']))

    missing_sections = doc_section_numbers - yaml_sections
    missing_subsections = doc_subsection_numbers - yaml_subsections

    results = {
        'missing_sections': sorted([(s, doc_section_map.get(s, 'Unknown')) for s in missing_sections], key=lambda x: x[0]),
        'missing_subsections': sorted([(s, doc_section_map.get(s, 'Unknown')) for s in missing_subsections], key=lambda x: x[0]),
        'covered_sections': sorted([(s, doc_section_map.get(s, 'Unknown')) for s in yaml_sections if s in doc_section_numbers], key=lambda x: x[0]),
        'covered_subsections': sorted([(s, doc_section_map.get(s, 'Unknown')) for s in yaml_subsections if s in doc_subsection_numbers], key=lambda x: x[0])
    }

    return results

def save_to_csv(results, output_csv_path: str):
    if not results:
        print("No results to save due to previous errors.")
        return

    csv_data = []
    csv_data.append(["Type", "Section/Subsection Number", "Name", "Status"])
    
    for section, name in results['missing_sections']:
        csv_data.append(["Section", section, name, "Missing"])
    for subsection, name in results['missing_subsections']:
        csv_data.append(["Subsection", subsection, name, "Missing"])
    for section, name in results['covered_sections']:
        csv_data.append(["Section", section, name, "Covered"])
    for subsection, name in results['covered_subsections']:
        csv_data.append(["Subsection", subsection, name, "Covered"])

    try:
        with open(output_csv_path, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(csv_data)
        print(f"Results successfully saved to {output_csv_path}")
    except Exception as e:
        print(f"Error writing to CSV: {e}")

if __name__ == "__main__":
    doc_path = r"C:\Solutions\ValidationFramework\includes\srs_validator\input\CQure_Insurance_SRS_Set1.docx"
    yaml_path = r'C:\Solutions\ValidationFramework\includes\srs_validator\output\f8bc9ab4-7828-41a0-bace-988dae8e0607\merged_requirements.yaml'

    output_csv_path = r"C:\Solutions\ValidationFramework\includes\srs_validator\output\f8bc9ab4-7828-41a0-bace-988dae8e0607\comparison_results.csv"
    
    try:
        results = compare_sections(doc_path, yaml_path)
        print(results)
        save_to_csv(results, output_csv_path)
    except FileNotFoundError as e:
        print(f"Error: File not found - {e}")
    except Exception as e:
        print(f"An error occurred: {e}")