import yaml
import json

def human_msg_to_json_yaml(human_msg):
    parsed_str = ""
    if isinstance(human_msg, str):
        try:
            # Try parsing JSON
            parsed_str = json.loads(human_msg)
        except json.JSONDecodeError:
            try:
                # Try parsing YAML
                parsed_str = yaml.safe_load(human_msg)
            except yaml.YAMLError as e:
                raise ValueError("Invalid input: not valid JSON or YAML") from e

    return parsed_str
