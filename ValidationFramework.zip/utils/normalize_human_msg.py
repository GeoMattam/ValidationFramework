import json
import yaml

def is_json_string(data):
    """Check if the input string is valid JSON."""
    if not isinstance(data, str):
        return False
    try:
        json.loads(data)
        return True
    except json.JSONDecodeError:
        return False

def is_yaml_string(data):
    """Check if the input string is valid YAML."""
    if not isinstance(data, str):
        return False
    try:
        yaml.safe_load(data)
        return True
    except yaml.YAMLError:
        return False

def normalize_to_human_message_content(input_data):
    # Case 1: String input
    if isinstance(input_data, str):
        # Check if it's a JSON string
        if is_json_string(input_data):
            try:
                parsed_data = json.loads(input_data)
                # Return as formatted JSON string
                return json.dumps(parsed_data, indent=2, ensure_ascii=False)
            except json.JSONDecodeError:
                # If JSON parsing fails, treat as plain string
                return input_data
        # Check if it's a YAML string
        elif is_yaml_string(input_data):
            try:
                parsed_data = yaml.safe_load(input_data)
                # Return as formatted YAML string
                return yaml.dump(parsed_data, sort_keys=False, allow_unicode=True)
            except yaml.YAMLError:
                # If YAML parsing fails, treat as plain string
                return input_data
        # Plain string, return as-is
        return input_data
    
    # Case 2: List of strings or dicts
    if isinstance(input_data, list):
        if all(isinstance(item, (str, dict)) for item in input_data):
            # Convert dict items to JSON strings, keep strings as-is
            return [json.dumps(item, indent=2, ensure_ascii=False) if isinstance(item, dict) else item for item in input_data]
        else:
            # Convert non-string/non-dict items to strings
            return [json.dumps(item, indent=2, ensure_ascii=False) if isinstance(item, dict) else str(item) for item in input_data]
    
    # Case 3: Dictionary (assumed to be parsed JSON/YAML)
    if isinstance(input_data, dict):
        # Convert to JSON for consistency with list handling
        return json.dumps(input_data, indent=2, ensure_ascii=False)
    
    # Fallback: Convert to string
    return str(input_data)
