from docx import Document
import re

def extract_number_heading_with_content(doc_path: str):
    doc = Document(doc_path)
    heading_numbers = []
    heading_names = []
    heading_contents = []
    current_content = []
    current_heading = None
    current_level = None
    heading_stack = []  

    for paragraph in doc.paragraphs:
        if paragraph.style.name.startswith('Heading'):
            if current_heading:
                heading_contents.append(' '.join(current_content).strip())
                current_content = []

            heading_level = int(paragraph.style.name.split()[1])
            heading_text = paragraph.text.strip()
            heading_numbers.append(str(heading_level))
            heading_names.append(heading_text)
            current_heading = heading_text
            current_level = heading_level
            heading_stack = heading_stack[:heading_level-1] + [heading_text]
        elif paragraph.text.strip() and current_heading:
            current_content.append(paragraph.text.strip())

    if current_heading and current_content:
        heading_contents.append(' '.join(current_content).strip())

    heading_sections_result = []
    chapter = 1
    for i in range(len(heading_numbers)):
        if heading_numbers[i] == '1':
            heading_sections_result.append(str(chapter))
            chapter += 1
        else:
            if i > 0 and int(heading_numbers[i]) > int(heading_numbers[i-1]):
                if int(heading_numbers[i]) == 2:
                    heading_sections_result.append(heading_sections_result[-1] + '.1')
                else:
                    heading_sections_result.append(heading_sections_result[-1] + '.1' * (int(heading_numbers[i]) - 2))
            elif i > 0 and int(heading_numbers[i]) == int(heading_numbers[i-1]):
                u = heading_sections_result[-1].split('.')
                u[-1] = str(int(u[-1]) + 1)
                heading_sections_result.append('.'.join(u))
            elif i > 0 and int(heading_numbers[i]) < int(heading_numbers[i-1]):
                u = heading_sections_result[-1].split('.')
                u = u[:int(heading_numbers[i])]
                u[-1] = str(int(u[-1]) + 1)
                heading_sections_result.append('.'.join(u))
            else:
                heading_sections_result.append(str(chapter) + '.1' * (int(heading_numbers[i]) - 1))

    total_heading = []
    for i in range(len(heading_numbers)):
        heading_key = f"{heading_sections_result[i]} {heading_names[i]}"
        content_value = heading_contents[i] if i < len(heading_contents) else ""
        total_heading.append({heading_key: content_value})

    return total_heading

def filter_by_top_level(total_heading: list, top_level: str):
    combined_content = []
    for heading in total_heading:
        for key in heading:
            if key.startswith(top_level + ' ') or key.startswith(top_level + '.'):
                combined_content.append(key)  # Include the heading
                if heading[key].strip():
                    combined_content.append(heading[key])  # Include the content if non-empty
    return ' '.join(combined_content).strip()

def filter_by_range(total_heading: list, start: str, end: str):
    result = []
    current_top_level = None
    current_content = []
    in_range = False

    def section_number_to_tuple(section: str) -> tuple:
        """Convert section number to tuple of integers for comparison."""
        return tuple(int(x) for x in section.split('.'))

    start_tuple = section_number_to_tuple(start)
    end_tuple = section_number_to_tuple(end)

    for heading in total_heading:
        for key in heading:
            section_number = key.split(' ')[0]
            section_tuple = section_number_to_tuple(section_number)
            top_level = section_number if '.' not in section_number else section_number[:section_number.index('.')]

            # Start collecting when reaching the start section
            if section_number == start:
                in_range = True
                current_top_level = section_number
                current_content = [key]
                if heading[key].strip():
                    current_content.append(heading[key])
                continue

            # Collect content if in range
            if in_range:
                # Include the section if it's the current top-level or its subsection
                if section_number == current_top_level or section_number.startswith(current_top_level + '.'):
                    current_content.append(key)
                    if heading[key].strip():
                        current_content.append(heading[key])
                # Start a new top-level section if within the range
                elif '.' in section_number and section_number[:section_number.index('.')] == top_level and section_tuple <= end_tuple:
                    if current_content:
                        result.append({current_top_level: ' '.join(current_content).strip()})
                    current_top_level = section_number
                    current_content = [key]
                    if heading[key].strip():
                        current_content.append(heading[key])
                # Stop after processing the end section and its subsections
                elif section_tuple > end_tuple and not section_number.startswith(end + '.'):
                    if current_content:
                        result.append({current_top_level: ' '.join(current_content).strip()})
                    in_range = False
                    break

    # Save the last section's content if still in range
    if in_range and current_content and current_top_level:
        result.append({current_top_level: ' '.join(current_content).strip()})

    return result

def filter_by_range_single_string(total_heading: list, start: str, end: str):
    combined_content = []
    in_range = False

    def section_number_to_tuple(section: str) -> tuple:
        """Convert section number to tuple of integers for comparison."""
        return tuple(int(x) for x in section.split('.'))

    start_tuple = section_number_to_tuple(start)
    end_tuple = section_number_to_tuple(end)

    for heading in total_heading:
        for key in heading:
            section_number = key.split(' ')[0]
            section_tuple = section_number_to_tuple(section_number)

            # Start collecting when reaching the start section
            if section_number == start:
                in_range = True
                combined_content.append(key)
                if heading[key].strip():
                    combined_content.append(heading[key])
                continue

            # Collect content if in range
            if in_range:
                if section_tuple <= end_tuple or section_number.startswith(end + '.'):
                    combined_content.append(key)
                    if heading[key].strip():
                        combined_content.append(heading[key])
                else:
                    break

    return [{f"{start} to {end}": ' '.join(combined_content).strip()}]

if __name__ == "__main__":
    doc_path = "C:/Solutions/ValidationFramework/includes/srs_validator/input/CQure_Insurance_SRS_Set1.docx"
    total_heading = extract_number_heading_with_content(doc_path)
    
    print("Headings between 3.6 and 3.9 (separate sections):")
    print(filter_by_range(total_heading, '3.10', '3.12'))

    additional_context = filter_by_top_level(total_heading, '1')
    print(additional_context)
        
