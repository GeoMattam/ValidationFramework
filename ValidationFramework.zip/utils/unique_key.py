import uuid

def generate_uniquekey():
    myuuid = uuid.uuid4()
    return myuuid
