import yaml

def load_yaml_file(file_path):
    """
    Loads and returns the content of a YAML file as a Python dictionary or list.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            data = yaml.safe_load(file)
            print("YAML content loaded successfully:")
            return data
    except FileNotFoundError:
        print(f"Error: File not found - {file_path}")
    except yaml.YAMLError as exc:
        print(f"YAML error: {exc}")
    except Exception as e:
        print(f"Unexpected error: {e}")