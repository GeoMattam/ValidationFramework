import streamlit as st
from streamlit_option_menu import option_menu
import pandas as pd
import uuid
import base64
import json
import os
import yaml
from yaml.parser import ParserError
from yaml.scanner import ScannerError
from docx import Document
from PyPDF2 import PdfReader

# TODO: Uncomment when using actual extract_requirements
from src.srsvalidator.extract_requirements import extract_requirements
# from src.srsvalidator.extract_requirements_dummy import extract_requirements
from src.srsvalidator.srs_g_eval_workflow import initialize_workflow, run_workflow_step
from utils.parse_human_msg import human_msg_to_json_yaml

st.set_page_config(layout="wide")

if 'myuuid' not in st.session_state:
    st.session_state.myuuid = str(uuid.uuid4())
if 'uploaded_file_info' not in st.session_state:
    st.session_state.uploaded_file_info = []
if 'extracted_files' not in st.session_state:
    st.session_state.extracted_files = {}
if 'g_eval_graph' not in st.session_state:
    st.session_state.g_eval_graph = None
if 'g_eval_current_state' not in st.session_state:
    st.session_state.g_eval_current_state = {}
if 'g_eval_interrupt' not in st.session_state:
    st.session_state.g_eval_interrupt = None
if 'srs_content_for_geval' not in st.session_state:
    st.session_state.srs_content_for_geval = None
if 'feedback_text' not in st.session_state:
    st.session_state.feedback_text = ""
if 'show_file' not in st.session_state:
    st.session_state.show_file = False
if 'manual_srs_file' not in st.session_state:
    st.session_state.manual_srs_file = None
if 'output_format' not in st.session_state:
    st.session_state.output_format = None

style_css = """
    .container {padding: 0 !important; background-color: #33374B;}
    .nav-link {font-size: 14px; text-align: center; margin: 0px;}
    .nav-link-selected {background-color: #1195CE; color: white;}
    h1, h2, h3 {color: #FFFFFF;}
    .stMarkdown, .stText {color: #D3D3D3;}
    .stButton>button {background-color: #1195CE; color: white; border-radius: 5px;}
    .stRadio>label {color: #D3D3D3;}
    .stSelectbox>label {color: #D3D3D3;}
    .stFileUploader>label {color: #D3D3D3;}
    table {
        border: 1px solid #1195CE;
        border-collapse: collapse;
        width: 100%;
    }
    th, td {
        border: 1px solid #1195CE;
        padding: 8px;
        text-align: left;
    }
    th {
        text-align: center;
        background-color: #0E7AB5;
        color: white;
    }
    .download-container {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    .download-btn {
        background-color: transparent;
        color: white;
        padding: 8px 16px;
        text-decoration: none;
        border: 1px solid #1195CE;
        border-radius: 5px;
        display: inline-block;
    }
    .download-btn:hover {
        background-color: #0E7AB5;
        color: white;
    }
"""
st.markdown(f"<style>{style_css}</style>", unsafe_allow_html=True)

def get_download_link(content: pd.DataFrame, filename: str, link_text: str) -> str:
    csv = content.to_csv(index=False).encode('utf-8')
    b64 = base64.b64encode(csv).decode('ascii')
    href = f'<a href="data:file/csv;base64,{b64}" download="{filename}" class="download-btn">{link_text}</a>'
    return href

sub_option = option_menu(
    menu_title=None,
    options=["Home", "Upload Documents", "SRS Extracts"],
    orientation="horizontal",
    styles={
        "container": {"padding": "0!important", "background-color": "#33374B"},
        "nav-link": {"font-size": "14px", "text-align": "center", "margin": "0px"},
        "nav-link-selected": {"background-color": "#1195CE", "color": "white"}
    }
)

if sub_option == "Home":
    st.markdown("""
        # SRS Validator
        Welcome to the SRS Validator application. This tool allows you to upload Software Requirements Specification (SRS) documents, validate them, and extract key requirements into categorized files. Use the navigation menu to:
        - **Upload Documents**: Upload your SRS document for processing.
        - **SRS Extracts**: View and download extracted Functional, Non-Functional, and Business Rules requirements, or evaluate the SRS using G-Evaluation, G-Eval with Manual Correction, or Semantic Evaluator.
    """, unsafe_allow_html=True)

elif sub_option == "Upload Documents":
    st.markdown(f"Session ID: {st.session_state.myuuid}")
    st.subheader("Upload SRS Document")
    
    file_type = st.selectbox(
        "Select document type",
        ["Software Requirements Specification"],
        key="file_type_select"
    )
    
    existing_file = next((info for info in st.session_state.uploaded_file_info if info["type"] == file_type), None)
    
    if existing_file:
        st.warning(f"File for type '{file_type}' already uploaded: {existing_file['file'].name}")
    else:
        uploaded_file = st.file_uploader("Choose an SRS document", type=["md", "txt","pdf", "docx", "doc"], key="file_uploader")
        if st.button("Add File"):
            if uploaded_file is None:
                st.warning("Please choose a file before pressing the add button!")
            else:
                st.session_state.uploaded_file_info.append({
                    "type": file_type,
                    "file": uploaded_file
                })
                st.success(f"Added {uploaded_file.name} as {file_type}.")
                st.session_state.g_eval_graph = None
                st.session_state.g_eval_current_state = {}
                st.session_state.g_eval_interrupt = None
                st.session_state.srs_content_for_geval = None
                st.session_state.feedback_text = ""
                st.session_state.manual_srs_file = None
                # st.rerun()
    
    st.subheader("Uploaded Files")
    if st.session_state.uploaded_file_info:
        for idx, info in enumerate(st.session_state.uploaded_file_info):
            file_label = f"{idx}. {info['file'].name} (Type: {info['type']})"
            with st.expander(file_label):
                try:
                    extension = os.path.splitext(info["file"].name)[1].lstrip(".")
                    print(extension)
                    if extension in ["md","txt"]:
                        file_text = info["file"].getvalue().decode("utf-8")
                    elif extension == "docx":
                        doc = Document(info["file"])
                        file_text = "\n".join([para.text for para in doc.paragraphs])                        
                    elif extension == "pdf":
                        reader = PdfReader(info["file"])
                        content = ""
                        for page in reader.pages:
                            content += page.extract_text()
                            
                except Exception:
                    file_text = "File cannot be decoded as text."
                st.text_area("File Content:", value=file_text, height=400, key=f"file_view_{idx}")
                if st.button(f"Remove {info['file'].name}", key=f"remove_{idx}"):
                    st.session_state.uploaded_file_info.pop(idx)
                    st.session_state.extracted_files = {}
                    st.session_state.g_eval_graph = None
                    st.session_state.g_eval_current_state = {}
                    st.session_state.g_eval_interrupt = None
                    st.session_state.srs_content_for_geval = None
                    st.session_state.feedback_text = ""
                    st.session_state.manual_srs_file = None
                    st.rerun()
    else:
        st.write("No files uploaded yet!")

elif sub_option == "SRS Extracts":
    st.markdown(f"Session ID: {st.session_state.myuuid}")
    
    if not st.session_state.uploaded_file_info:
        st.warning("Please upload an SRS document in the Upload Documents section!")
    else:
        srs_file = next((info["file"] for info in st.session_state.uploaded_file_info if info["type"] == "Software Requirements Specification"), None)
        if not srs_file:
            st.warning("No SRS document found!")
        else:
            try:
                extension = os.path.splitext(srs_file.name)[1].lstrip(".")
                srs_content = ""

                if extension in ["md","txt"]:
                    srs_content = srs_file.getvalue().decode("utf-8")
                elif extension == "docx":
                    doc = Document(srs_file)
                    srs_content = "\n".join([para.text for para in doc.paragraphs])                        
                elif extension == "pdf":
                    reader = PdfReader(srs_file)
                    for page in reader.pages:
                        srs_content += page.extract_text()
                            
                st.session_state.srs_content_for_geval = srs_content
            except Exception:
                srs_content = None
                st.error("Error decoding SRS file.")
            
            option = st.radio(
                "Select Extraction or Evaluation Method",
                ["Requirements Extraction", "G-Evaluation", "G-Eval with Manual Correction"],
                horizontal=True,
                key="extract_option"
            )
            
            if option == "Requirements Extraction":
                option_output_format = st.radio(
                                    "Select JSON or YAML for the output format",
                                    ["JSON", "YAML"],
                                    horizontal=True,
                                    key="output_format_key"
                                    )
                st.session_state.output_format = option_output_format

                st.subheader("Extracted Requirements")
                if srs_content:
                    if st.button("Process Requirements", key="process_requirements"):
                        with st.spinner("Extracting requirements..."):
                            print("srs_content:",srs_content)
                            st.session_state.extracted_files = extract_requirements(srs_content,option_output_format)
                            st.rerun()
                
                if st.session_state.extracted_files:
                    if isinstance(st.session_state.extracted_files, str):
                        if st.session_state.extracted_files.get("combined", "").startswith("Error:"):
                            st.error(st.session_state.extracted_files["combined"])
                    else:
                        tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
                            "Functional Requirements",
                            "Non-Functional Requirements",
                            "Business Rules",
                            "Ambiguous Requirements",
                            "Other Observations",
                            "Combined Requirements"
                        ])
                        
                        with tab1:
                            if st.session_state.extracted_files["functional"]:
                                df_functional = pd.DataFrame(st.session_state.extracted_files["functional"])
                                df_functional_display = df_functional[["requirement_id", "requirement_text", "original_text", "source_section", "page_number", "line_number"]]
                                df_functional_display.columns = ["ID", "Requirement", "Original Text", "Section", "Page", "Line"]
                                st.markdown("### Functional Requirements")
                                st.markdown(df_functional_display.to_html(index=False), unsafe_allow_html=True)
                                st.markdown(
                                    f'<div class="download-container">{get_download_link(df_functional_display, "functional_requirements.csv", "Download Functional Requirements")}</div>',
                                    unsafe_allow_html=True
                                )
                            else:
                                st.write("No Functional Requirements extracted.")
                        
                        with tab2:
                            if st.session_state.extracted_files["non_functional"]:
                                df_non_functional = pd.DataFrame(st.session_state.extracted_files["non_functional"])
                                df_non_functional_display = df_non_functional[["requirement_id", "requirement_text", "original_text", "source_section", "page_number", "line_number"]]
                                df_non_functional_display.columns = ["ID", "Requirement", "Original Text", "Section", "Page", "Line"]
                                st.markdown("### Non-Functional Requirements")
                                st.markdown(df_non_functional_display.to_html(index=False), unsafe_allow_html=True)
                                st.markdown(
                                    f'<div class="download-container">{get_download_link(df_non_functional_display, "non_functional_requirements.csv", "Download Non-Functional Requirements")}</div>',
                                    unsafe_allow_html=True
                                )
                            else:
                                st.write("No Non-Functional Requirements extracted.")
                        
                        with tab3:
                            if st.session_state.extracted_files["business_rules"]:
                                df_business_rules = pd.DataFrame(st.session_state.extracted_files["business_rules"])
                                df_business_rules_display = df_business_rules[["requirement_id", "requirement_text", "original_text", "source_section", "page_number", "line_number"]]
                                df_business_rules_display.columns = ["ID", "Rule", "Original Text", "Section", "Page", "Line"]
                                st.markdown("### Business Rules")
                                st.markdown(df_business_rules_display.to_html(index=False), unsafe_allow_html=True)
                                st.markdown(
                                    f'<div class="download-container">{get_download_link(df_business_rules_display, "business_rules.csv", "Download Business Rules")}</div>',
                                    unsafe_allow_html=True
                                )
                            else:
                                st.write("No Business Rules extracted.")
                        
                        with tab4:
                            if st.session_state.extracted_files["ambiguous"]:
                                df_ambiguous = pd.DataFrame(st.session_state.extracted_files["ambiguous"])
                                df_ambiguous_display = df_ambiguous[["requirement_id", "requirement_text", "reason", "source_section", "page_number", "line_number"]]
                                df_ambiguous_display.columns = ["ID", "Requirement", "Reason for Clarification", "Section", "Page", "Line"]
                                st.markdown("### Ambiguous or Subjective Requirements")
                                st.markdown(df_ambiguous_display.to_html(index=False), unsafe_allow_html=True)
                                st.markdown(
                                    f'<div class="download-container">{get_download_link(df_ambiguous_display, "ambiguous_requirements.csv", "Download Ambiguous Requirements")}</div>',
                                    unsafe_allow_html=True
                                )
                            else:
                                st.write("No Ambiguous or Subjective Requirements extracted.")
                        
                        with tab5:
                            if st.session_state.extracted_files["observations"]:
                                df_observations = pd.DataFrame(st.session_state.extracted_files["observations"])
                                df_observations_display = df_observations[["observation_id", "observation_text", "page_number", "line_number"]]
                                df_observations_display.columns = ["ID", "Observation", "Page", "Line"]
                                st.markdown("### Other Observations")
                                st.markdown(df_observations_display.to_html(index=False), unsafe_allow_html=True)
                                st.markdown(
                                    f'<div class="download-container">{get_download_link(df_observations_display, "observations.csv", "Download Observations")}</div>',
                                    unsafe_allow_html=True
                                )
                            else:
                                st.write("No Other Observations extracted.")
                        
                        with tab6:
                            st.markdown("### Combined Requirements")
                            combined_data = st.session_state.extracted_files.get("combined")
                            if combined_data:
                                try:
                                    # First try to parse as JSON
                                    if isinstance(combined_data, str):
                                        parsed = json.loads(combined_data)
                                        st.json(parsed)
                                    elif isinstance(combined_data, dict) or isinstance(combined_data, list):
                                        st.json(combined_data)
                                    else:
                                        raise ValueError  # fallback to YAML/text
                                except (json.JSONDecodeError, TypeError, ValueError):
                                    try:
                                        # Try parsing as YAML
                                        if isinstance(combined_data, str):
                                            parsed_yaml = yaml.safe_load(combined_data)
                                            st.code(yaml.dump(parsed_yaml, sort_keys=False), language="yaml")
                                        else:
                                            # already dict/list: YAML-compatible
                                            st.code(yaml.dump(combined_data, sort_keys=False), language="yaml")
                                    except (ParserError, ScannerError, yaml.YAMLError):
                                        # Fallback to plain text
                                        st.text_area("Combined Requirements", value=str(combined_data), height=500)
                            else:
                                st.write("No Combined Requirements available.")

                else:
                    st.info("Click 'Process Requirements' to extract requirements from the uploaded SRS document.")
            
            elif option == "G-Evaluation":
                st.subheader("G-Evaluation")
                if st.session_state.srs_content_for_geval:
                    if not st.session_state.extracted_files.get("combined"):
                        if st.button("Extract Requirements for G-Eval", key="extract_for_g_eval"):
                            with st.spinner("Extracting requirements..."):
                                st.session_state.extracted_files = extract_requirements(st.session_state.srs_content_for_geval,st.session_state.output_format)
                                st.rerun()

                    if st.session_state.extracted_files.get("combined"):
                        if st.session_state.g_eval_graph is None:
                            st.session_state.g_eval_graph = initialize_workflow()

                        if not st.session_state.g_eval_current_state:
                            if st.button("Run G-Evaluation", key="run_g_eval_first_time"):
                                with st.spinner("Running G-Evaluation..."):
                                    output, interrupt_info = run_workflow_step(
                                        st.session_state.g_eval_graph,
                                        st.session_state.srs_content_for_geval,
                                        st.session_state.extracted_files,
                                        st.session_state.myuuid,
                                        1,
                                        st.session_state.output_format
                                    )
                                    if output:
                                        st.session_state.g_eval_current_state = output
                                    st.session_state.g_eval_interrupt = interrupt_info
                                    st.rerun()

                        else:
                            if st.session_state.g_eval_current_state:
                                current_node = list(st.session_state.g_eval_current_state.keys())[0]
                                g_eval_state = st.session_state.g_eval_current_state[current_node]
                                messages = g_eval_state.get('messages', [])
                            else:
                                st.error("No G-Eval state available. Please run G-Evaluation again.")
                                messages = []

                            # Collect all G-Eval JSON results from messages
                            g_eval_results = []
                            for msg in messages:
                                msg_type = getattr(msg, 'type', None) or (msg.get('type') if isinstance(msg, dict) else None)
                                content = getattr(msg, 'content', None) or (msg.get('content') if isinstance(msg, dict) else None)
                                if msg_type == 'ai' and content.strip().startswith('{'):
                                    try:
                                        json.loads(content)
                                        g_eval_results.append((content, len(g_eval_results) + 1))
                                    except json.JSONDecodeError:
                                        continue
                                elif msg_type == 'human' and "Feedback received" in content:
                                    st.info(content)

                            # Display G-Eval results in expanders
                            if g_eval_results:
                                st.markdown("### G-Eval Results")
                                for json_str, iteration in g_eval_results:
                                    try:
                                        g_eval_data = json.loads(json_str)
                                        with st.expander(f"G-Eval Result (Iteration {iteration})"):
                                            st.json(g_eval_data)
                                    except json.JSONDecodeError:
                                        with st.expander(f"Invalid G-Eval Result (Iteration {iteration})"):
                                            st.error("Invalid JSON format in G-Eval result.")
                                            st.text_area("Raw G-Eval Result", json_str, height=400)
                            else:
                                st.warning("No G-Eval results available yet.")

                            if st.session_state.g_eval_interrupt:
                                st.subheader("Approve or Provide Feedback")
                                approval_option = st.radio("Do you approve the G-Evaluation results?", ["Approve", "Provide Feedback"], key="approval_option")
                                feedback_input = ""
                                if approval_option == "Provide Feedback":
                                    feedback_input = st.text_area("Enter your feedback:", value=st.session_state.feedback_text, key="feedback_input")
                                if st.button("Submit Feedback", key="submit_feedback"):
                                    with st.spinner("Processing feedback..."):
                                        feedback_to_send = "approved" if approval_option == "Approve" else feedback_input
                                        if approval_option == "Approve":
                                            st.session_state.show_file = True
                                        output, interrupt_info = run_workflow_step(
                                            st.session_state.g_eval_graph,
                                            st.session_state.srs_content_for_geval,
                                            st.session_state.extracted_files,
                                            st.session_state.myuuid,
                                            st.session_state.g_eval_current_state.get(current_node, {}).get('iteration', 1),
                                            feedback=feedback_to_send
                                        )
                                        if output:
                                            for node, state in output.items():
                                                st.session_state.g_eval_current_state[node] = {
                                                    **st.session_state.g_eval_current_state.get(node, {}),
                                                    **state
                                                }
                                        st.session_state.g_eval_interrupt = interrupt_info

                                        if st.session_state.g_eval_current_state:
                                            current_node = list(st.session_state.g_eval_current_state.keys())[0]
                                            current_state = st.session_state.g_eval_current_state[current_node]
                                            if current_state.get('srs'):
                                                st.session_state.srs_content_for_geval = current_state['srs'][-1].content
                                            if current_state.get('extracted_requirements'):
                                                st.session_state.extracted_files = human_msg_to_json_yaml(current_state['extracted_requirements'][-1].content)

                                        # Clear the feedback text
                                        if approval_option == "Provide Feedback":
                                            st.session_state.feedback_text = ""

                                        if interrupt_info is None:
                                            # Display final SRS file path
                                            file_path = f"{os.getenv('ROOT_PATH', '')}srs_validator/output/updated_srs/{st.session_state.myuuid}/srs_freezed.md"
                                            st.success(f"G-Evaluation workflow completed! Final SRS saved at: {file_path}")
                                            st.session_state.g_eval_current_state = {}
                                            st.session_state.g_eval_graph = None
                                            st.session_state.g_eval_interrupt = None
                                            st.session_state.feedback_text = ""
                                            st.session_state.manual_srs_file = None
                                        st.rerun()
                            else:
                                # Display final SRS file path if workflow is complete
                                if st.session_state.show_file:
                                    file_path = f"{os.getenv('ROOT_PATH', '')}srs_validator/output/updated_srs/{st.session_state.myuuid}/srs_freezed.md"
                                    st.success(f"G-Evaluation workflow completed! Final SRS saved at: {file_path}")
                    else:
                        st.warning("Combined requirements not extracted. Please extract them first.")
                else:
                    st.error("SRS document is required for G-Evaluation.")

            elif option == "G-Eval with Manual Correction":
                st.subheader("G-Eval with Manual Correction")
                if st.session_state.srs_content_for_geval:
                    if not st.session_state.extracted_files.get("combined"):
                        if st.button("Extract Requirements for G-Eval with Manual Correction", key="extract_for_g_eval_manual"):
                            with st.spinner("Extracting requirements..."):
                                st.session_state.extracted_files = extract_requirements(st.session_state.srs_content_for_geval,st.session_state.output_format)
                                st.rerun()

                    if st.session_state.extracted_files.get("combined"):
                        if st.session_state.g_eval_graph is None:
                            st.session_state.g_eval_graph = initialize_workflow(is_manual=True)

                        if not st.session_state.g_eval_current_state:
                            if st.button("Run G-Eval with Manual Correction", key="run_g_eval_manual_first_time"):
                                with st.spinner("Running G-Eval with Manual Correction..."):
                                    output, interrupt_info = run_workflow_step(
                                        st.session_state.g_eval_graph,
                                        st.session_state.srs_content_for_geval,
                                        st.session_state.extracted_files,
                                        st.session_state.myuuid,
                                        1
                                    )
                                    if output:
                                        st.session_state.g_eval_current_state = output
                                    st.session_state.g_eval_interrupt = interrupt_info
                                    st.rerun()

                        else:
                            if st.session_state.g_eval_current_state:
                                current_node = list(st.session_state.g_eval_current_state.keys())[0]
                                g_eval_state = st.session_state.g_eval_current_state[current_node]
                                messages = g_eval_state.get('messages', [])
                            else:
                                st.error("No G-Eval state available. Please run G-Eval with Manual Correction again.")
                                messages = []

                            # Collect all G-Eval JSON results from messages
                            g_eval_results = []
                            for msg in messages:
                                msg_type = getattr(msg, 'type', None) or (msg.get('type') if isinstance(msg, dict) else None)
                                content = getattr(msg, 'content', None) or (msg.get('content') if isinstance(msg, dict) else None)
                                if msg_type == 'ai' and content.strip().startswith('{'):
                                    try:
                                        json.loads(content)
                                        g_eval_results.append((content, len(g_eval_results) + 1))
                                    except json.JSONDecodeError:
                                        continue
                                elif msg_type == 'human' and "Feedback received" in content:
                                    st.expander("Updated SRS").markdown(content)
                                    # st.info(content)

                            # Display G-Eval results in expanders
                            if g_eval_results:
                                st.markdown("### G-Eval Results")
                                for json_str, iteration in g_eval_results:
                                    try:
                                        g_eval_data = json.loads(json_str)
                                        with st.expander(f"G-Eval Result (Iteration {iteration})"):
                                            st.json(g_eval_data)
                                    except json.JSONDecodeError:
                                        with st.expander(f"Invalid G-Eval Result (Iteration {iteration})"):
                                            st.error("Invalid JSON format in G-Eval result.")
                                            st.text_area("Raw G-Eval Result", json_str, height=400)
                            else:
                                st.warning("No G-Eval results available yet.")

                            if st.session_state.g_eval_interrupt:
                                st.subheader("Approve or Upload Updated SRS")
                                approval_option = st.radio("Do you approve the G-Eval results?", ["Approve", "Upload Updated SRS"], key="approval_option_manual")
                                if approval_option == "Upload Updated SRS":
                                    st.session_state.manual_srs_file = st.file_uploader("Upload updated SRS document", type=["md", "txt"], key="manual_srs_uploader")
                                if st.button("Submit", key="submit_manual"):
                                    with st.spinner("Processing submission..."):
                                        if approval_option == "Approve":
                                            feedback_to_send = "approved"
                                        elif approval_option == "Upload Updated SRS" and st.session_state.manual_srs_file:
                                            try:
                                                feedback_to_send = st.session_state.manual_srs_file.getvalue().decode("utf-8")
                                            except Exception as e:
                                                st.error(f"Error decoding uploaded SRS file: {str(e)}")
                                                st.rerun()
                                        else:
                                            st.error("Please upload an SRS document before submitting.")
                                            st.rerun()

                                        if approval_option == "Approve":
                                            st.session_state.show_file = True
                                        output, interrupt_info = run_workflow_step(
                                            st.session_state.g_eval_graph,
                                            st.session_state.srs_content_for_geval,
                                            st.session_state.extracted_files,
                                            st.session_state.myuuid,
                                            st.session_state.g_eval_current_state.get(current_node, {}).get('iteration', 1),
                                            feedback=feedback_to_send
                                        )
                                        if output:
                                            for node, state in output.items():
                                                st.session_state.g_eval_current_state[node] = {
                                                    **st.session_state.g_eval_current_state.get(node, {}),
                                                    **state
                                                }
                                        st.session_state.g_eval_interrupt = interrupt_info

                                        if st.session_state.g_eval_current_state:
                                            current_node = list(st.session_state.g_eval_current_state.keys())[0]
                                            current_state = st.session_state.g_eval_current_state[current_node]
                                            if current_state.get('srs'):
                                                st.session_state.srs_content_for_geval = current_state['srs'][-1].content
                                            if current_state.get('extracted_requirements'):
                                                st.session_state.extracted_files = human_msg_to_json_yaml(current_state['extracted_requirements'][-1].content)

                                        # Clear the manual SRS file
                                        if approval_option == "Upload Updated SRS":
                                            st.session_state.manual_srs_file = None

                                        if interrupt_info is None:
                                            # Display final SRS file path
                                            file_path = f"{os.getenv('ROOT_PATH', '')}srs_validator/output/updated_srs/{st.session_state.myuuid}/srs_freezed.md"
                                            st.success(f"G-Eval with Manual Correction workflow completed! Final SRS saved at: {file_path}")
                                            st.session_state.g_eval_current_state = {}
                                            st.session_state.g_eval_graph = None
                                            st.session_state.g_eval_interrupt = None
                                            st.session_state.feedback_text = ""
                                            st.session_state.manual_srs_file = None
                                        st.rerun()
                            else:
                                # Display final SRS file path if workflow is complete
                                if st.session_state.show_file:
                                    file_path = f"{os.getenv('ROOT_PATH', '')}srs_validator/output/updated_srs/{st.session_state.myuuid}/srs_freezed.md"
                                    st.success(f"G-Eval with Manual Correction workflow completed! Final SRS saved at: {file_path}")
            elif option == "Semantic Evaluator":
                st.subheader("Semantic Evaluator")
                if srs_content:
                    with st.spinner("Evaluating semantics..."):
                        #from utils.backend_dummy import semantic_evaluator
                        #result = semantic_evaluator(srs_content)
                        st.write("Semantic Evaluation Result:")
                        #st.write(result)
                else:
                    st.error("SRS document is required for semantic evaluation.")