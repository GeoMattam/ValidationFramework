srs_clarifyAI="""
You are a business analyst reading a Business Requirements Document (BRD).

Extract all the business requirements from the following text. For each requirement, return:
-  requirement_id - a unique ID (e.g., REQ-001, REQ-002...)
-  requirement_text - clear, concise statement of the requirement
-  Only return a JSON list of requirements.
-  Do not include code or markdown. Do not explain.

Return a JSON array in this exact format:
    [ "requirement id": "REQ-001",  "requirement text": "Text of the extracted requirement" ]

IMPORTANT:
    - Do NOT use Markdown or triple backticks.
    - Do NOT add explanations.
    - Respond only with a raw JSON object (no markdown, no json fences, no explanation).

BRD Content:
```{SRS}```

"""

srs_extract_requirements_without_objective = """
You are an expert Business Analyst and System Architect.

Your task is to extract all the following from the provided System Requirements Specification (SRS) document:
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)

Please follow the exact output format shown below.

---
### SRS Document:
```{SRS}```

---
### Output Format:

**Functional Requirements**
| Requirement ID | Description |
|----------------|-------------|
| FR001 | [Functional Requirement 1] |
| FR002 | [Functional Requirement 2] |
| ...   | ... |

**Non-Functional Requirements**
| Requirement ID | Description |
|----------------|-------------|
| NFR001 | [Non-Functional Requirement 1] |
| NFR002 | [Non-Functional Requirement 2] |
| ...    | ... |

**Business Rules**
| Rule ID | Description |
|---------|-------------|
| BR001 | [Business Rule 1] |
| BR002 | [Business Rule 2] |
| ...   | ... |

**Ambiguous or Subjective Requirements (Needs Clarification)**
| ID | Original Text | Reason for Ambiguity or Suggestion for Clarification |
|----|----------------|---------------------------------------------|
| Q001 | “System should be user-friendly” | Vague — define usability metrics (e.g., task completion time, satisfaction score) |
| Q002 | “UI must be modern and intuitive” | Subjective — suggest describing UI standards or frameworks |

### Guidelines:
- Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
- Keep requirement descriptions concise and clear.
- Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
- Maintain structured tables.

"""


srs_extract_requirements_with_objective= """
You are an expert Business Analyst and System Architect. Extract all the requirements in an objective manner mentioned in SRS, be it business or 
functional and any non-functional requirements that are needed to build the system.

Your task is to extract all the following in an objective manner from the provided System Requirements Specification (SRS) document:
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)

Please follow the exact output format shown below.

---
### SRS Document:
```{SRS}```

---
### Output Format:

**Functional Requirements**
| Requirement ID | Description |
|----------------|-------------|
| FR001 | [Functional Requirement 1] |
| FR002 | [Functional Requirement 2] |
| ...   | ... |

**Non-Functional Requirements**
| Requirement ID | Description |
|----------------|-------------|
| NFR001 | [Non-Functional Requirement 1] |
| NFR002 | [Non-Functional Requirement 2] |
| ...    | ... |

**Business Rules**
| Rule ID | Description |
|---------|-------------|
| BR001 | [Business Rule 1] |
| BR002 | [Business Rule 2] |
| ...   | ... |

**Ambiguous or Subjective Requirements (Needs Clarification)**
| ID | Original Text | Reason for Ambiguity or Suggestion for Clarification |
|----|----------------|---------------------------------------------|
| Q001 | “System should be user-friendly” | Vague — define usability metrics (e.g., task completion time, satisfaction score) |
| Q002 | “UI must be modern and intuitive” | Subjective — suggest describing UI standards or frameworks |

### Guidelines:
- Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
- Keep requirement descriptions concise and clear.
- Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
- Maintain structured tables.

"""


srs_extract_requirements_without_objective_json = """
You are an expert Business Analyst and System Architect.

Your task is to extract all the following from the provided System Requirements Specification (SRS) document:
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)

Please follow the exact output format shown below.

---
### SRS Document:
```{SRS}```

---
### Output Format:

**Functional Requirements**
[ "requirement_id": "FR001",  "requirement_text": "Text of the extracted requirement" ]


**Non-Functional Requirements**
[ "requirement_id": "NFR001",  "requirement_text": "Text of the extracted requirement" ]

**Business Rules**
[ "requirement_id": "BR001",  "requirement_text": "Text of the extracted requirement" ]

**Ambiguous or Subjective Requirements (Needs Clarification)**
[ "requirement_id": "Q001",  "requirement_text": "ystem should be user-friendly", "reason":"Vague — define usability metrics" ]

### Guidelines:
- Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
- Keep requirement descriptions concise and clear.
- Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.

"""


srs_extract_requirements_with_objective_json= """

You are an expert Business Analyst and System Architect. Extract all the requirements in an objective manner mentioned in SRS, be it business or 
functional and any non-functional requirements that are needed to build the system.

Your task is to extract all the following in an objective manner from the provided System Requirements Specification (SRS) document:
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)

Please follow the exact output format shown below.

---
### SRS Document:
```{SRS}```

---
### Output Format:

**Functional Requirements**
[ "requirement_id": "FR001",  "requirement_text": "Text of the extracted requirement" ]


**Non-Functional Requirements**
[ "requirement_id": "NFR001",  "requirement_text": "Text of the extracted requirement" ]

**Business Rules**
[ "requirement_id": "BR001",  "requirement_text": "Text of the extracted requirement" ]

**Ambiguous or Subjective Requirements (Needs Clarification)**
[ "requirement_id": "Q001",  "requirement_text": "ystem should be user-friendly", "reason":"Vague — define usability metrics" ]


### Guidelines:
- Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
- Keep requirement descriptions concise and clear.
- Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.

"""

srs_extract_additional_comments = """
You are an expert Business Analyst and System Architect. Extract all the requirements in an objective manner mentioned in the SRS, be it business, functional, or non-functional, and highlight any unclear or vague requirements.

Your task is to extract all the following in an objective manner from the provided System Requirements Specification (SRS) document:
    - Functional Requirements (FR)
    - Non-Functional Requirements (NFR)
    - Business Rules (BR)
    - Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)
    - Other Observations (repetitions, conflicts, missing modules)

Please follow the exact output format shown below.

---
### SRS Document:
```{SRS}```

---
### Output Format:

**Functional Requirements**
["requirement_id": "FR001", "requirement_text": "System shall allow students to reset password via email", "source_section": "3.2.1" ]

**Non-Functional Requirements**
["requirement_id": "NFR001", "requirement_text": "System should be available 100 percentage of the time", "source_section": "4.1.1" ]

**Business Rules**
["requirement_id": "BR001", "requirement_text": "A student can register for a maximum of 5 courses per semester", "source_section": "3.4" ]

**Ambiguous or Subjective Requirements (Needs Clarification)**
["requirement_id": "Q001", "requirement_text": "System should be user-friendly", "reason":"Vague — define usability metrics", "source_section": "5.2.1" ]

**Other_Observations**
["observation_id": "OBS001", "observation_text": "Conflicting requirement: section 3.5 says max file size is 2MB, section 3.8 says 5MB" ]

### Guidelines:
    - Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
    - If a requirement contains multiple sub-requirements, split each into its own item with a unique ID (e.g., FR001-a, FR001-b).
    - Keep requirement descriptions concise and clear.
    - Try to include the SRS section number (if available) for traceability.
    - Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
    - NFRs can include performance, security, scalability, usability, availability, maintainability, audit, or compliance goals.
    - Business Rules include domain logic, constraints, validations, calculations, or mandatory conditions that must be enforced.

"""


srs_extract_additional_comments_objective = """
You are an expert Business Analyst and System Architect. Extract all the requirements in an objective manner mentioned in SRS, be it business or 
functional and any non-functional requirements that are needed to build the system.

Your task is to extract all the following in an objective manner from the provided System Requirements Specification (SRS) document:
    - Functional Requirements (FR)
    - Non-Functional Requirements (NFR)
    - Business Rules (BR)
    - Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)
    - Other Observations (repetitions, conflicts, missing modules)

Please follow the exact output format shown below.

---
### SRS Document:
```{SRS}```

---
### Output Format:

**Functional Requirements**
["requirement_id": "FR001", "requirement_text": "System shall allow students to reset password via email", "source_section": "3.2.1" ]

**Non-Functional Requirements**
["requirement_id": "NFR001", "requirement_text": "System should be available 100 percentage of the time", "source_section": "4.1.1" ]

**Business Rules**
["requirement_id": "BR001", "requirement_text": "A student can register for a maximum of 5 courses per semester", "source_section": "3.4" ]

**Ambiguous or Subjective Requirements (Needs Clarification)**
["requirement_id": "Q001", "requirement_text": "System should be user-friendly", "reason":"Vague — define usability metrics", "source_section": "5.2.1" ]

**Other_Observations**
["observation_id": "OBS001", "observation_text": "Conflicting requirement: section 3.5 says max file size is 2MB, section 3.8 says 5MB" ]

### Guidelines:
    - Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
    - If a requirement contains multiple sub-requirements, split each into its own item with a unique ID (e.g., FR001-a, FR001-b).
    - Keep requirement descriptions concise and clear.
    - Try to include the SRS section number (if available) for traceability.
    - Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
    - NFRs can include performance, security, scalability, usability, availability, maintainability, audit, or compliance goals.
    - Business Rules include domain logic, constraints, validations, calculations, or mandatory conditions that must be enforced.

"""

srs_extract_additional_comments_objective_1_aemo = """
You are an expert Business Analyst and System Architect. Extract all the requirements in an objective manner mentioned in SRS, be it business or 
functional and any non-functional requirements that are needed to build the system.

Your task is to extract all the following in an objective manner from the provided System Requirements Specification (SRS) document:
    - Functional Requirements (FR)
    - Non-Functional Requirements (NFR)
    - Business Rules (BR)
    - Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)
    - Other Observations (repetitions, conflicts, missing modules)

Please follow the exact output format shown below.

---
### SRS Document:
```{SRS}```

---
### Output Format:

**Functional Requirements**
[
    "requirement_id": "FR001",
    "requirement_text": "System shall allow students to reset their password via email",
    "original_text": "The student should be able to change their password using a reset link sent to their registered email.",
    "source_section": "3.2.1",
    "page_number": 5,
    "line_number": 142
]

**Non-Functional Requirements**
[
    "requirement_id": "NFR001",
    "requirement_text": "System should maintain 99.9% uptime over a calendar month.",
    "original_text": "The system should always be available and must have 99.9% uptime.",
    "source_section": "4.1.1",
    "page_number": 8,
    "line_number": 207
]

**Business Rules**
[
    "requirement_id": "BR001",
    "requirement_text": "A student can register for a maximum of 5 courses per semester.",
    "original_text": "Students are not allowed to enroll in more than 5 courses each semester.",
    "source_section": "3.4",
    "page_number": 6,
    "line_number": 178
]

**Ambiguous or Subjective Requirements (Needs Clarification)**
[
    "requirement_id": "Q001",
    "requirement_text": "System should be user-friendly",
    "original_text": "The system should be user-friendly and visually pleasing.",
    "reason": "Vague — 'user-friendly' and 'visually pleasing' need measurable criteria.",
    "source_section": "5.2.1",
    "page_number": 9,
    "line_number": 222
]

**Other_Observations**
[
    "observation_id": "OBS001",
    "observation_text": "Conflicting file size limits: section 3.5 says max upload is 2MB, but section 3.8 says 5MB.",
    "page_number": 7,
    "line_number": 192
]

### Guidelines:
    - Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
    - If a requirement contains multiple sub-requirements, split each into its own item with a unique ID (e.g., FR001-a, FR001-b).
    - Keep requirement descriptions concise and clear.  
    - Include source_section, page_number, and line_number where available for traceability.
    - Try to include the SRS section number (if available) for traceability.
    - Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
    - NFRs can include performance, security, scalability, usability, availability, maintainability, audit, or compliance goals.
    - Business Rules include domain logic, constraints, validations, calculations, or mandatory conditions that must be enforced.

"""


srs_extract_additional_comments_objective_1 = """
You are an expert Business Analyst and System Architect. Extract all the requirements in an objective manner mentioned in SRS, be it business or 
functional and any non-functional requirements that are needed to build the system.

Your task is to extract all the following in an objective manner from the provided System Requirements Specification (SRS) document:
    - Functional Requirements (FR)
    - Non-Functional Requirements (NFR)
    - Business Rules (BR)
    - Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)
    - Other Observations (repetitions, conflicts, missing modules)

Please follow the exact output format shown below.

---
### SRS Document:
```{SRS}```

---
### Output Format:
Return the output as a raw JSON object in the exact format shown below.
```json   
{
    "Functional Requirements": [
        {
            "requirement_id": "FR001",
            "requirement_text": "System shall allow students to reset their password via email",
            "original_text": "The student should be able to change their password using a reset link sent to their registered email.",
            "source_section": "3.2.1",
            "page_number": 5,
            "line_number": 142
        }
    ],
    "Non-Functional Requirements": [
        {
            "requirement_id": "NFR001",
            "requirement_text": "System should maintain 99.9% uptime over a calendar month.",
            "original_text": "The system should always be available and must have 99.9% uptime.",
            "source_section": "4.1.1",
            "page_number": 8,
            "line_number": 207
        }
    ],
    "Business Rules": [
        {
            "requirement_id": "BR001",
            "requirement_text": "A student can register for a maximum of 5 courses per semester.",
            "original_text": "Students are not allowed to enroll in more than 5 courses each semester.",
            "source_section": "3.4",
            "page_number": 6,
            "line_number": 178
        }
    ],
    "Ambiguous or Subjective Requirements": [
        {
            "requirement_id": "Q001",
            "requirement_text": "System should be user-friendly",
            "original_text": "The system should be user-friendly and visually pleasing.",
            "reason": "Vague — 'user-friendly' and 'visually pleasing' need measurable criteria.",
            "source_section": "5.2.1",
            "page_number": 9,
            "line_number": 222
        }
    ],
    "Other_Observations": [
        {
            "observation_id": "OBS001",
            "observation_text": "Conflicting file size limits: section 3.5 says max upload is 2MB, but section 3.8 says 5MB.",
            "page_number": 7,
            "line_number": 192
        }
    ]
}

### Guidelines:
    - Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
    - If a requirement contains multiple sub-requirements, split each into its own item with a unique ID (e.g., FR001-a, FR001-b).
    - Keep requirement descriptions concise and clear.  
    - Include source_section, page_number, and line_number where available for traceability.
    - Try to include the SRS section number (if available) for traceability.
    - Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
    - NFRs can include performance, security, scalability, usability, availability, maintainability, audit, or compliance goals.
    - Business Rules include domain logic, constraints, validations, calculations, or mandatory conditions that must be enforced.

"""

srs_extract_additional_comments_objective_1_JSON="""
You are an expert Business Analyst and System Architect. Your task is to extract all the requirements from the provided SRS (System Requirements Specification) for a greenfield application in a structured, objective, and traceable manner.

Please extract and classify the following:
- Functional Requirements (FR)
- Non-Functional Requirements (NFR)
- Business Rules (BR)
- Ambiguous or Subjective Requirements (Q)
- Other Observations (OBS)

---

### SRS Document:
```{SRS}```

---
### Output Format:
Use strict JSON-style formatting with each section in a code block, as shown in the example below:

```json   
{
    "Functional Requirements": [
        {
            "requirement_id": "FR001",
            "requirement_text": "System shall allow students to reset their password via email",
            "original_text": "The student should be able to change their password using a reset link sent to their registered email.",
            "source_section": "3.2.1",
            "page_number": 5,
            "line_number": 142
        }
    ],
    "Non-Functional Requirements": [
        {
            "requirement_id": "NFR001",
            "requirement_text": "System should maintain 99.9% uptime over a calendar month.",
            "original_text": "The system should always be available and must have 99.9% uptime.",
            "source_section": "4.1.1",
            "page_number": 8,
            "line_number": 207
        }
    ],
    "Business Rules": [
        {
            "requirement_id": "BR001",
            "requirement_text": "A student can register for a maximum of 5 courses per semester.",
            "original_text": "Students are not allowed to enroll in more than 5 courses each semester.",
            "source_section": "3.4",
            "page_number": 6,
            "line_number": 178
        }
    ],
    "Ambiguous or Subjective Requirements": [
        {
            "requirement_id": "Q001",
            "requirement_text": "System should be user-friendly",
            "original_text": "The system should be user-friendly and visually pleasing.",
            "reason": "Vague — 'user-friendly' and 'visually pleasing' need measurable criteria.",
            "source_section": "5.2.1",
            "page_number": 9,
            "line_number": 222
        }
    ],
    "Other_Observations": [
        {
            "observation_id": "OBS001",
            "observation_text": "Conflicting file size limits: section 3.5 says max upload is 2MB, but section 3.8 says 5MB.",
            "page_number": 7,
            "line_number": 192
        }
    ]
}

### Guidelines for Extraction:
    1. Coverage & Completeness
        - Review all important functional and business activities in the document.
        - Ensure no critical action, rule, or constraint is missed.
        - Include any mention of external system interactions or integration points if they appear.        
    2. Requirement Classification
        - Accurately distinguish between:
            - Functional Requirements: System capabilities or behaviors.
            - Business Rules: Domain-specific constraints, validations, limits.
            - Non-Functional: Performance, security, availability, usability.
        - If a statement can be classified as both FR and BR, include it in both with clear reasoning.
        - Keep requirement descriptions concise and clear.
    3. Contextual Consistency
        - Preserve preceding qualifiers (e.g., "only if", "based on", "when approved") and succeeding actions.
        - Don't extract a statement out of context — retain any dependent clauses that change its meaning.
    4. Terminology Alignment
        - If the SRS uses domain-specific terms like “function”, “activity”, “business action”, do not auto-convert them to “system”. Retain the original terminology wherever applicable.
    5. No Oversimplification
        - When simplifying or rephrasing long sentences, ensure no meaning is lost.
        - If needed, split into multiple sub-requirements with suffixes like "FR005-a", "FR005-b".
    6. Traceability
        - Always include original_text, source_section, page_number, and line_number to trace back to the source.
        - If section or page numbers are missing, infer logically or mention "unknown".
    7. Ambiguous or Subjective Content
         - Flag any vague terms (e.g., "user-friendly", "fast") under Ambiguous Requirements and provide a reason for why it is unclear or unmeasurable.
    8. Other Observations
        - Highlight inconsistencies, missing modules, or conflicting statements (e.g., upload size defined differently in two sections).

### Final Note:
Return only the required JSON-formatted output under each heading. Do not include explanations, summaries, or analysis outside the specified structure.
"""


srs_extract_additional_comments_objective_1_YAML="""

You are a highly skilled Business Analyst and System Architect.

Your task is to carefully analyze the provided System Requirements Specification (SRS) document and extract the following items in an objective and structured manner:

1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements (vague, unclear, or unmeasurable statements)
5. Other Observations (e.g., missing modules, conflicting information, repetitions)

Please return the output in the following YAML format with inline comments to help with traceability and understanding.

---
### SRS Document:
```{SRS}```
---

### Output Format:
```yaml
Functional Requirements:
  - requirement_id: FR001  # Unique ID for traceability
    requirement_text: "System shall allow students to reset their password via email"  # Clean, actionable requirement
    original_text: "The student should be able to change their password using a reset link sent to their registered email."  # Original phrasing from the SRS
    source_section: "3.2.1"  # SRS section reference
    page_number: 5  # Page number in the source document
    line_number: 142  # Line number for direct reference

Non-Functional Requirements:
  - requirement_id: NFR001
    requirement_text: "System should maintain 99.9% uptime over a calendar month."
    original_text: "The system should always be available and must have 99.9% uptime."
    source_section: "4.1.1"
    page_number: 8
    line_number: 207

Business Rules:
  - requirement_id: BR001
    requirement_text: "A student can register for a maximum of 5 courses per semester."
    original_text: "Students are not allowed to enroll in more than 5 courses each semester."
    source_section: "3.4"
    page_number: 6
    line_number: 178

Ambiguous or Subjective Requirements:
  - requirement_id: Q001
    requirement_text: "System should be user-friendly"
    original_text: "The system should be user-friendly and visually pleasing."
    reason: "Vague — 'user-friendly' and 'visually pleasing' need measurable criteria."
    source_section: "5.2.1"
    page_number: 9
    line_number: 222

Other_Observations:
  - observation_id: OBS001
    observation_text: "Conflicting file size limits: section 3.5 says max upload is 2MB, but section 3.8 says 5MB."
    page_number: 7
    line_number: 192

###Guidelines:
    - Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
    - If a requirement contains multiple sub-requirements, split each into its own item with a unique ID (e.g., FR001-a, FR001-b).
    - Keep requirement descriptions concise and clear.  
    - Include source_section, page_number, and line_number where available for traceability.
    - Try to include the SRS section number (if available) for traceability.
    - Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
    - NFRs can include performance, security, scalability, usability, availability, maintainability, audit, or compliance goals.
    - Business Rules include domain logic, constraints, validations, calculations, or mandatory conditions that must be enforced.
    - Use YAML format with comments (#) to annotate the purpose of each field for reviewers.

"""

srs_extract_additional_comments_objective_YAML_plain_V1 = """

You are a highly skilled Business Analyst and System Architect.

Your task is to carefully analyze the following System Requirements Specification (SRS) and extract:

1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements
5. Other Observations

Use YAML format with inline comments (#) and include IDs like FR001, NFR001, etc. Add section/page/line info if available. Keep it clean and objective.

### SRS Document
{SRS}

### Now extract and output in the following YAML structure:
{YAML}

"""

srs_extract_additional_comments_objective_YAML_plain_V2 = """
You are a highly skilled Business Analyst and System Architect.

Your task is to carefully analyze the following System Requirements Specification (SRS) and extract structured information into the categories below:

Extract and Classify Into:
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements
5. Other Observations

Guidelines:

- ID Management:
  Use provided IDs if available; otherwise, generate logical IDs (e.g., FR001, NFR002, etc.).
  For compound requirements, split into sub-requirements using IDs like FR001-a, FR001-b.

- Actor Field:
  Include the primary actor involved in the requirement (e.g., User, Admin, System).

- Requirement Structure:
  Each item should contain:
    - requirement_id
    - requirement_text — clear, objective interpretation
    - original_text — as written in the SRS
    - actor — who performs or receives the action
    - source_section, source_sub_section
    - page_number, line_number
  For ambiguous requirements, include a reason field explaining why it is considered vague.

- Traceability:
  Include section, sub-section, page, and line numbers where possible to trace the requirement back to the SRS.

- Category Definitions:
  Functional Requirements: Core system behavior
  Non-Functional Requirements: Performance, security, usability, availability, maintainability, etc.
  Business Rules: Domain logic, validations, thresholds
  Ambiguous Requirements: Vague, subjective, or unmeasurable language
  Other Observations: Conflicting statements, missing elements, inconsistencies

- Output Format:
  Use valid YAML
  Add inline comments (#) to explain fields where appropriate

SRS Document:
{SRS}

Now output the extracted requirements in the following YAML structure:
{YAML}

"""

srs_extract_additional_comments_objective_YAML_plain_V3 = """
You are a highly skilled Business Analyst and System Architect.
Your task is to carefully analyze the following System Requirements Specification (SRS) and extract structured information into the categories below:

Extract and Classify Into
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements
5. Other Observations

Guidelines
- ID Management
    Use provided IDs if available; otherwise, generate logical IDs (e.g., FR001, NFR002, etc.).
    For compound requirements, split into sub-requirements using IDs like FR001-a, FR001-b.

- Actor Field
    Include the primary actor involved in the requirement (e.g., User, Admin, System).

- Requirement Structure
    For each requirement, include:
     - requirement_id — unique identifier
     - requirement_text — clear, objective interpretation of the requirement
     - original_text — exact wording from the SRS
     - actor — who performs or receives the action
     - source_section, source_sub_section
     - page_number, line_number
     - pre_conditions — list of necessary states or actions that must be true before the requirement can be executed
     - post_conditions — list of states or outcomes that must be true after the requirement is executed

    For ambiguous requirements only — include a reason field explaining why it is vague.
    Include two additional fields for every requirement:
    
- Traceability
    Include section, sub-section, page, and line numbers wherever possible for traceability.

- Category Definitions
    1. Functional Requirements (FR): Core system behavior
    2. Non-Functional Requirements (NFR): Performance, security, usability, availability, maintainability, etc.
    3. Business Rules (BR): Domain logic, constraints, thresholds
    4. Ambiguous Requirements: Vague, subjective, or unmeasurable statements
    5. Other Observations: Conflicting statements, missing details, inconsistencies

- Output Format
    Use valid YAML format.
    Add inline comments (#) where necessary to clarify intent.

Follow exactly the structure below:
{YAML}

SRS Document:
{SRS}

"""


srs_extract_additional_comments_objective_YAML_plain_V4 = """
You are a highly skilled Business Analyst and System Architect.

Analyze the following System Requirements Specification (SRS) and extract every requirement-like statement across 
the entire document (main text, tables, footnotes, appendices). Do not skip anything. When in doubt, include it.

## Extract and Classify Into
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements
5. Other Observations

## Guidelines
- ID Management
    1. Use provided IDs if present; otherwise generate sequential IDs (FR001, FR002… / NFR001… / BR001…).
    2. For compound requirements, split into sub-requirements (FR001-a, FR001-b, …). Prefer splitting over summarizing.

## Actor
- Populate the primary actor (User, Admin, System, Third-Party, etc.).

## Fields for each requirement (all categories except “Other Observations”)
- requirement_id
- requirement_text — clear, objective interpretation (no loss of scope/conditions/limits)
- original_text — verbatim, unabridged SRS text of the requirement (do not paraphrase; include the full sentence/row)
- actor
- source_section, source_sub_section
- page_number, line_number
- pre_conditions — list of necessary states before execution
- post_conditions — list of outcomes after execution
- For ambiguous items only, add reason explaining the ambiguity/subjectivity.

## If any metadata is unavailable, set the field to null (do not omit the requirement).

## Category definitions
- FR: Core system behavior and capabilities
- NFR: Performance, security, usability, availability, maintainability, etc.
- BR: Domain rules, constraints, limits, thresholds, validations
- Ambiguous: Vague/subjective/unmeasurable (e.g., “user-friendly”, “modern”)
- Other Observations: Conflicts, duplications, gaps, contradictions, TBDs

## Coverage & splitting
- Be exhaustive. Include all relevant statements.
- If output would exceed limits, split across multiple YAML documents separated by --- and continue until complete. Do not drop categories or fields.

## Output Format
- Output valid YAML only (no extra commentary).
- Include empty lists where applicable. Use null for unknown scalars.
- Preserve special characters by quoting strings as needed.

Follow exactly the structure below:
{YAML}

SRS Document:
{SRS}

"""

srs_extract_additional_comments_objective_YAML_plain_V5 = """
You are a highly skilled Business Analyst and System Architect.

Analyze the following SRS Specific Requirement together with its Additional Context (Introduction, General Description ,Interface Requirements)
Extract every requirement-like statement in the SRS Specific Requirement (from main text, subsections, tables, figures). 

## Important constraints:
 - Use ONLY the text present in the provided SRS chunk and its three companion documents.
 - Do not invent text or infer beyond what is explicitly written.
 - If metadata is unavailable, set it to null.
 - Never omit fields.

## Extract and Classify Into
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements
5. Other Observations

## Guidelines
- ID Management
	1. Use provided IDs if present.
	2. Otherwise, generate sequential IDs (FR001, FR002… / NFR001… / BR001…).
	3. For compound requirements, always split into sub-requirements (FR001-a, FR001-b). Never merge or summarize.

- Actor
	Populate the primary actor (User, Admin, System, Third-Party, etc.).

- Fields for each requirement (all categories except Other Observations)
	1. requirement_id
	2. requirement_text — clear, objective rewrite, preserving full scope and conditions (no omissions).
	3. original_text — verbatim, unabridged text from the SRS (exact sentence, row, or clause).
	4. actor
    5. source_section_name & source_sub_section_name
	6. source_section, source_sub_section
	7. page_number, line_number
	8. pre_conditions — list of necessary states before execution
	9  post_conditions — list of outcomes after execution
	10. fields — (if applicable) structured fields from forms, with type, editable/auto-populated
	11. validations — (if applicable) constraints, regex, rules, error messages
	12. For ambiguous items only: add reason explaining ambiguity/subjectivity.

- Other Observations
	Include conflicts, TBDs, duplications, contradictions.

- Missing Metadata
	1. If any metadata is unavailable, set it to null.
	2. Never omit a field.

- Category Definitions
	1. FR: Core system behavior and capabilities
	2. NFR: Performance, security, usability, availability, maintainability, etc.
	3. BR: Domain rules, constraints, limits, thresholds, validations
	4. Ambiguous: Vague/subjective/unmeasurable (e.g., “user-friendly”, “modern”)
	5. Other Observations: Conflicts, duplications, gaps, contradictions, TBDs

## Output Format
1. Output valid YAML only (no commentary).
2. Include empty lists where applicable.
3. Use null for missing metadata.
4. Quote strings with special characters.

Follow exactly the structure below:
```{YAML}```

SRS Specific Requirement:
```{specific_requirement}```

Additional Context
```{additional_context}```

"""

G_Eval_style_prompt_SRS="""
You are an expert Business Analyst and System Architect.

You are reviewing a set of extracted requirements — including functional requirements, non-functional requirements, and business rules — that were derived from a Software Requirements Specification (SRS) document.

Your task is to evaluate whether the extracted content accurately and completely represents the original SRS.

Please assess the extracted content against the SRS based on the following dimensions:

1. **Coverage** Are all important functional, non-functional, and business rule elements from the SRS captured in the extracted content?
2. **Correctness** Are the extracted requirements accurate in meaning and intent compared to the original SRS?
3. **Completeness** Are any major SRS requirements missing, generalized, or partially extracted?
4. **Clarity** Are the extracted items clearly written, well-structured, and free of ambiguity?
5. **Redundancy or Noise** Are there any duplicate, irrelevant, or incorrectly extracted items?

Return your evaluation in the following JSON format. Use a score from **1 (poor)** to **5 (excellent)** for each dimension, and include a brief comment explaining your reasoning.

```json
{{
  "Coverage": {{"score": _, "comment": "…"}},
  "Correctness": {{"score": _, "comment": "…"}},
  "Completeness": {{"score": _, "comment": "…"}},
  "Clarity": {{"score": _, "comment": "…"}},
  "RedundancyOrNoise": {{"score": _, "comment": "…"}}
}}

### Input: Original SRS Document
{srs}

### Input: Extracted Requirements
{extracted_requirements}

"""

srs_extract_additional_comments_objective_YAML_plain_V6 = """
You are a highly skilled Business Analyst.

Analyze the following Specific Requirement along with its Additional Context ( for example; Introduction, General Description ,Interface Requirements) in order to
keep the common elements as additional information.

Extract every requirement or requirement-like statements in the Specific Requirement (from main text, subsections, tables, figures). 

## Important constraints:
 - Use ONLY the text or information present in the provided chunk and its three companion documents.
 - Do not imagine or produce text not present in the documents and do not provide your own inference beyond what is explicitly written.
 - If metadata is unavailable, set it to null.
 - Never omit fields. Consider all the fields.
 - Take into account the information contained in the previous and next sections of information in order to get the broader context.

## Extract and Classify Into
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements
5. Other Observations

## Guidelines
- ID Management
	1. Use provided IDs if present.
	2. Otherwise, generate sequential IDs where the id differs by one (FR001, FR002… / NFR001… / BR001…).
	3. For compound requirements, always split into sub-requirements (FR001-a, FR001-b). Never merge or summarize.

- Actor
	Populate the primary actor (roles like User, Admin, System, Third-Party).

- Fields for each requirement (all categories except Other Observations)
	1. requirement_id
	2. requirement_text — clear, objective rewrite, preserving full scope and conditions (no omission of information and no addition of information  not present in the documents).
	3. original_text — verbatim, unabridged text from the requirement (exact sentence, row, column or clause).
	4. actor
    5. source_section_name & source_sub_section_name
	6. source_section, source_sub_section
	7. page_number, line_number
	8. pre_conditions — list of necessary states before execution
	9  post_conditions — list of outcomes after execution
	10. fields — (if applicable) structured fields from forms, with type, editable/auto-populated
	11. validations — (if applicable) constraints, regex, rules, error messages
	12. For ambiguous items only: add reasons explaining ambiguity/subjectivity.

- Other Observations
	Include conflicts, TBDs (To be decided), duplications, contradictions.

- Missing Metadata
	1. If any metadata is unavailable, set it to null.
	2. Never omit a field.

- Category Definitions
	1. FR: Core system behavior and capabilities
	2. NFR: Performance, security, usability, availability, maintainability, etc.
	3. BR: Domain rules, constraints, limits, thresholds, validations
	4. Ambiguous: Vague/subjective/unmeasurable (e.g., “user-friendly”, “modern”)
	5. Other Observations: Conflicts, duplications, gaps, contradictions, TBDs

## Output Format
1. Output valid YAML only (no commentary).
2. Include empty lists where applicable.
3. Use null for missing metadata.
4. Quote strings with special characters.

Follow exactly the structure below:
```{YAML}```

Specific Requirement:
```{specific_requirement}```

Additional Context
```{additional_context}```

"""

srs_extract_additional_comments_objective_YAML_plain="""You are a highly skilled Business Analyst.
 
Analyze the following Specific Requirement along with its Additional Context ( for example; Introduction, General Description ,Interface Requirements) in order to keep the common elements as additional information.
Extract every requirement or requirement-like statements in the Specific Requirement (from main text, subsections, tables, figures). 
 
## Important constraints:
 - Use ONLY the text or information present in the provided chunk and its three companion documents.
 - Do not imagine or produce text not present in the documents and do not provide your own inference beyond what is explicitly written.
 - If metadata is unavailable, set it to null.
 - Never omit fields. Consider all the fields.
 - Take into account the information contained in the previous and next lines/sentences of information in order to get the broader context.
 - When extracting Functional and Non-Functional Requirements, ensure that the requirements are not repeated. Understand the logic behind the requirement and extract it strictly following the provided documents.
 - Do not split a SIMPLE requirement into different parts to create dulpiucate or redundant requirements. Preserve the information being depicted in the original requirement. Only split for compound requirements as mentioned in one of the guidelines below.
 - While reading the sections, go from top-to-bottom and left-to-right to ensure a linear progression of the extraction process.
 
## Extract and Classify Into
1. Functional Requirements (FR)
2. Non-Functional Requirements (NFR)
3. Business Rules (BR)
4. Ambiguous or Subjective Requirements
5. Other Observations
 
## Guidelines
- ID Management
 1. Use provided IDs if present.
 2. Otherwise, generate sequential IDs where the id differs by one (FR001, FR00... / NFR001... / BR001...).
 3. For compound requirements, always split into sub-requirements (FR001-a, FR001-b). Never merge or summarize.
 
- Actor
 Populate the primary actor (roles like User, Admin, System, Third-Party). Ensure that the proper actor is identified especially in cases where the original text includes User. If User is mentioned in the requirement and User performs an action, include that in the actor.
 
- Fields for each requirement (all categories except Other Observations)
 1. requirement_id
 2. requirement_text - clear, objective rewrite, preserving full scope and conditions (no omission of information and no addition of information not present in the documents).
 3. original_text - verbatim, unabridged text from the requirement (exact sentence, row, column or clause).
 4. actor
 5. source_section_name & source_sub_section_name
 6. source_section, source_sub_section
 7. page_number, line_number
 8. pre_conditions - list of necessary states which must be satisfied before execution 
 9. post_conditions - list of outcomes obtained after execution if the pre_conditions are satisfied and the operation is performed correctly.
 10. fields - (if applicable) structured fields from forms, with type, editable/auto-populated
 11. validations - (if applicable) constraints, regex, rules, error messages
 12. For ambiguous items only: add reasons explaining ambiguity/subjectivity.
 
- Other Observations
 Include conflicts, TBDs (To be decided), duplications, contradictions.
 While taking into account subheadings in a given section, ensure to use the correct subheading number as this is crucial for maintaining the flow of logic and information in the original document.
 
- Missing Metadata
 1. If any metadata is unavailable, set it to null.
 2. Never omit a field.
 
- Category Definitions
 1. FR: Core system behavior and capabilities
 2. NFR: Performance, security, usability, availability, maintainability, etc.
 3. BR: Domain rules, constraints, limits, thresholds, validations
 4. Ambiguous: Vague/subjective/unmeasurable (e.g., "user-friendly", "modern")
 5. Other Observations: Conflicts, duplications, gaps, contradictions, TBDs
 
## Output Format
1. Output valid YAML only (no commentary).
2. Include empty lists where applicable.
3. Use null for missing metadata.
4. Quote strings with special characters.
 
Follow exactly the structure below:
```{YAML}```
 
Specific Requirement:
```{specific_requirement}```
 
Additional Context
```{additional_context}```
 
"""