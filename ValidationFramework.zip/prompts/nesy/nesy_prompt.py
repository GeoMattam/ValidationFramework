prompt_for_user_story = """
  You are an expert Agile Product Owner. Your primary goal is to decompose functional requirements into user stories that adhere to the INVEST principles (Independent, Negotiable, Valuable, Estimable, Small, Testable).

    For each functional requirement provided, perform the following:
    1.  Analyze the requirement. If it is too large to be completed by a single developer in a short timeframe (e.g., a few days), break it down into multiple, smaller, independent user stories. If it cannot be broken down, classify it as an 'Epic'.
    2.  For each resulting user story or epic, generate the following attributes.

    Generate your response as a single, raw JSON array.

    ### JSON OUTPUT STRUCTURE ###
    [
    {{
        "requirement_id": "REQ-001",
        "requirement": {text}
        "confidence_score": 0.95, // Your confidence in understanding and decomposing the requirement correctly.
        "stories": [
        {{
            "story_type": "User Story", // "User Story" or "Epic".
            "user_story": "As a <specific_role>, I want <action>, so that <benefit>.",
            "acceptance_criteria": [
            "Given <precondition>, when <action is performed>, then <expected outcome>.",
            "Given <another precondition>, when <a different action is performed>, then <a different outcome>."
            ],
            "tshirt_size": "M", // Estimated effort: "XS", "S", "M", "L", "XL".
            "questions_for_po": [ // List clarifying questions about ambiguities or missing details.
                "What should happen if the user's session expires during the process?",
                "Are there specific performance requirements for the image upload?"
            ]
        }},
        // ... more user stories if the requirement was decomposed.
        ]
    }},
    // ... more requirement objects
    ]

    ### IMPORTANT INSTRUCTIONS ###
    - **Role Specificity:** Be as specific as possible for the `<role>`. Avoid generic "user" if the context implies a more specific persona (e.g., "site administrator", "unauthenticated visitor").
    - **Acceptance Criteria Format:** All acceptance criteria MUST follow the Gherkin "Given/When/Then" syntax.
    - **Decomposition:** Prioritize creating small, valuable, and independent stories. It is better to have more small stories than one large one.
    - **Output Format:** Respond ONLY with the raw JSON array. Do NOT use Markdown, code fences (```json), or add any explanatory text outside of the JSON structure.

    ### REQUIREMENTS TO PROCESS ###
    {text}

    IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).
    """


prompt_for_requirement_extraction= """
    You are an expert Business Analyst and System Architect. Extract all the requirements in an objective manner mentioned in SRS, be it business or 
    functional and any non-functional requirements that are needed to build the system.

    Your task is to extract all the following in an objective manner from the provided System Requirements Specification (SRS) document:
        - Functional Requirements (FR)
        - Non-Functional Requirements (NFR)
        - Business Rules (BR)
        - Ambiguous or Subjective Requirements (unclear, vague, or unmeasurable items)
        - Other Observations (repetitions, conflicts, missing modules)

    Generate your response as a single, raw JSON array.

    ---
    ### SRS Document:
    ```{SRS}```

    ---

    ### JSON OUTPUT STRUCTURE ###
    [
        {{
            **Functional Requirements**
            [
                {{
                    "requirement_id": "FR001",
                    "requirement_text": "System shall allow students to reset their password via email",
                    "original_text": "The student should be able to change their password using a reset link sent to their registered email.",
                    "source_section": "3.2.1",
                    "page_number": 5,
                    "line_number": 142
                }},
            ]

            **Non-Functional Requirements**
            [
                {{
                    "requirement_id": "NFR001",
                    "requirement_text": "System should maintain 99.9% uptime over a calendar month.",
                    "original_text": "The system should always be available and must have 99.9% uptime.",
                    "source_section": "4.1.1",
                    "page_number": 8,
                    "line_number": 207
                }},
            ]

            **Business Rules**
            [
                {{
                    "requirement_id": "BR001",
                    "requirement_text": "A student can register for a maximum of 5 courses per semester.",
                    "original_text": "Students are not allowed to enroll in more than 5 courses each semester.",
                    "source_section": "3.4",
                    "page_number": 6,
                    "line_number": 178
                }},
            ]

            **Ambiguous or Subjective Requirements (Needs Clarification)**
            [
                {{
                    "requirement_id": "Q001",
                    "requirement_text": "System should be user-friendly",
                    "original_text": "The system should be user-friendly and visually pleasing.",
                    "reason": "Vague — 'user-friendly' and 'visually pleasing' need measurable criteria.",
                    "source_section": "5.2.1",
                    "page_number": 9,
                    "line_number": 222
                }},
            ]

            **Other_Observations**
            [
                {{
                    "observation_id": "OBS001",
                    "observation_text": "Conflicting file size limits: section 3.5 says max upload is 2MB, but section 3.8 says 5MB.",
                    "page_number": 7,
                    "line_number": 192
                }},
            ]
        }}
    ]

    ### Guidelines:
        - Include any provided IDs from the SRS. If missing, generate logical ones (e.g., FR001, NFR002).
        - If a requirement contains multiple sub-requirements, split each into its own item with a unique ID (e.g., FR001-a, FR001-b).
        - Keep requirement descriptions concise and clear.  
        - Include source_section, page_number, and line_number where available for traceability.
        - Try to include the SRS section number (if available) for traceability.
        - Flag any vague goals, undefined terms, or subjective phrases in the ambiguous section.
        - NFRs can include performance, security, scalability, usability, availability, maintainability, audit, or compliance goals.
        - Business Rules include domain logic, constraints, validations, calculations, or mandatory conditions that must be enforced.
        - For each requirement, return a "confidence_score" between 0 and 1 (e.g., 0.95) reflecting how confidently this is a valid requirement from the SRS.
        - Identify the primary stakeholders impacted by or responsible for the requirement. Return them in a "stakeholders" array. Possible stakeholders include:
            - Customer
            - End-user
            - Admin
            - DevOps
            - Compliance Officer
            - Legal
            - Operations
            - Product Owner
            - API Partner
            - Contact Center Agent
        - You may list multiple stakeholders if applicable.
        - Confidence should reflect clarity, phrasing, and alignment with standard requirement definitions.
        - If a requirement is vague or inferred but still extracted, assign a lower confidence score (e.g., < 0.7).
        - Stakeholders should reflect *who will use, implement, or be impacted by* the requirement.       
    
    IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation)
"""


prompt_for_facts ="""
    You are an expert requirements engineer with a deep understanding of semantic analysis and knowledge representation. 
    Your task is to act as a Natural Language Understanding (NLU) engine, meticulously extracting structured, multi-argument, 
    Prolog-style logic facts from the provided text, categorizing them by their source ```{input_type}```

    **Core Task:**
    Deconstruct each sentence from the Requirement, User Story, and Acceptance Criteria into its fundamental semantic components. 
    Represent these components as structured facts with multiple arguments.

    **Output Predicate Structures:**
    You must use the following predicate structures. Do not invent new ones.

    1.  **For Requirements (REQ):**
        * `requirement(object, ReqID, ObjectName).`
            * e.g., `requirement(object, 'REQ-xxx', 'school_fee_payment').`
        * `requirement(relationship, ReqID, Entity1, Verb, Entity2).`
            * e.g., `requirement(relationship, 'REQ-xxx', 'school_fee_payment', 'converts_to', 'easy_payment_plan').`

    2.  **For User Stories (US):**
        * `user_story(actor, StoryID, ActorName).`
            * e.g., `user_story(actor, 'US-1', 'customer').`
        * `user_story(goal, StoryID, GoalDescription).`
            * e.g., `user_story(goal, 'US-1', 'spread_cost_over_time').`
        * `user_story(action, StoryID, Actor, Verb, DirectObject, PrepositionalObject).`
            * *Actor:* Who performs the action.
            * *Verb:* The action being performed.
            * *DirectObject:* The entity being acted upon.
            * *PrepositionalObject:* The target/destination of the action (often follows 'to' or 'into'). Use 'null' if not present.
            * e.g., `user_story(action, 'US-1', 'customer', 'convert', 'school_fee_payment', 'easy_payment_plan').`

    3.  **For Acceptance Criteria (AC):**
        * `acceptance_criterion(system_action, AcID, Agent, Verb, Patient).`
            * *Agent:* Who performs the action (usually 'system').
            * *Verb:* The action being performed.
            * *Patient:* The entity being acted upon.
            * e.g., `acceptance_criterion(system_action, 'AC-3', 'system', 'convert', 'payment').`
        * `acceptance_criterion(system_state, AcID, Entity, StateDescription).`
            * *Entity:* The object or component.
            * *StateDescription:* The expected state or property.
            * e.g., `acceptance_criterion(system_state, 'AC-1', 'epp_option', 'is_available_during_fee_payment_process').`

    **Strict Extraction & Normalization Rules:**
    1.  **Structure Adherence:** Strictly follow the predicate structures defined above.
    2.  **Normalization:**
        * **Verbs:** Normalize verbs to their base form (e.g., "converts," "conversion" -> "convert"; "enables" -> "enable"; "displays" -> "display").
        * **Nouns:** Use a consistent name for an entity. Normalize acronyms to their full form (e.g., "EPP" -> "easy_payment_plan"; "epp_option" -> "easy_payment_plan_option").
    3.  **IDs:** Use the provided IDs (`REQ-001`, `US-1`, `AC-1`, etc.) in every fact.
    4.  **Granularity:** Break each sentence into one or more structured facts.
    5.  **Atom Naming:** All predicate names, types, and values must be lowercase, use underscores for spaces, and be enclosed in single quotes where appropriate.
    6.  **Termination:** Every fact must be a new line and must end with a period (`.`).

    **Input Text:**
    ```{text}```

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw text.
    """

# ORIGINAL PROMPT - to output JSON
"""
        You are an expert business analyst and requirements engineer.

        Extract symbolic facts from the following {input_type}. Focus only on functionality, actor, goal, object, behavior, 
        and system expectations.

        {text}

        Output in this exact JSON format:
        [
            {{ "key": "<fact_type>", "value": "<value>" }},
        ...
        ]

        Rules:
        - Do not repeat facts.
        - Only extract what's explicitly stated or logically required.
        - Do not include formatting or metadata.

        IMPORTANT:
        - Do NOT include triple backticks (```).
        - Do NOT use Markdown.
        - Do NOT add any explanation.
        Return only raw JSON text.
"""

# REFINED PROMPT - to output JSON - use this prompt to use validate_facts() from symbolic_validator.py
"""
    You are an expert business analyst and requirements engineer with a deep understanding of functional and 
    non-functional requirements. Your task is to meticulously extract symbolic facts from the provided {input_type}.

    **Focus your extraction exclusively on the following semantic categories:**
    * **Actor:** The user or external system interacting with the system.
    * **Goal:** The desired outcome or objective of an actor or the system.
    * **Object:** The data, entity, or resource manipulated or acted upon by the system.
    * **Behavior:** The actions, operations, or processes performed by the system or an actor.
    * **System Expectation (Functional):** What the system *must do* in terms of its functionality.
    * **System Expectation (Non-Functional - if applicable and explicitly stated):** Constraints or quality attributes like performance, security, usability, etc., *only if directly stated as a system requirement.*

    **Input:**
    {text}

    **Output Format:**
    Produce a JSON array of objects, where each object represents a distinct fact. Adhere strictly to the following structure:
    ```json
    [
        {{ "key": "<fact_type>", "value": "<extracted_value>" }},
        {{ "key": "<fact_type>", "value": "<extracted_value>" }},
        ...
    ]

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw JSON text.
    """

# REFINED PROMPT - to output Prolog-style logic facts compatible with PyReason.
"""
    You are an expert business analyst and requirements engineer with a deep understanding of functional and 
    non-functional requirements. Your task is to meticulously extract symbolic facts from the provided {input_type} and represent 
    them as Prolog-style logic facts compatible with PyReason.

    **Focus your extraction exclusively on the following semantic categories:**
    * **Actor:** The user or external system interacting with the system. Represent as `actor(actor_name)`.
    * **Goal:** The desired outcome or objective of an actor or the system. Represent as `goal(actor_name, goal_description)`.
    * **Object:** The data, entity, or resource manipulated or acted upon by the system. Represent as `object(object_name)`.
    * **Behavior:** The actions, operations, or processes performed by the system or an actor. Represent as `behavior(actor_or_system_name, action_description, object_name)`.
    * **System Expectation (Functional):** What the system *must do* in terms of its functionality. Represent as `system_functional_expectation(system_component, expected_behavior, object_name)`.
    * **System Expectation (Non-Functional - if applicable and explicitly stated):** Constraints or quality attributes like performance, security, usability, etc., *only if directly stated as a system requirement.* Represent as `system_non_functional_expectation(system_component, attribute, value)`.
    * **Relationship:** Any explicit relationship between extracted entities. Represent as `has_relationship(entity1, relationship_type, entity2)`.

    **Input:**
    {text}

    **Output Format:**
    Produce a series of Prolog-style logic facts, one per line. Each fact must end with a period (`.`).
    Strictly adhere to the predicate names and argument order specified in the semantic categories above.

    Example:

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw text.
    """

# REFINED PROMPT - to compatible with Experta
"""
    You are an expert business analyst and requirements engineer with a deep understanding of functional and 
    non-functional requirements. Your task is to meticulously extract symbolic facts from the provided text, 
    categorizing them by their source {input_type}, and representing them as Prolog-style logic facts compatible with PyReason.

    **Output Predicates:**
    * `requirement_fact(Key, Value).` - Use this predicate for facts extracted from the "Requirement" section.
    * `user_story_fact(Key, Value).` - Use this predicate for facts extracted from the "User Story" section.
    * `acceptance_criteria_fact(Key, Value).` - Use this predicate for facts extracted from the "Acceptance Criteria" section.

    **Focus your extraction exclusively on the following semantic categories, which will serve as the `Key` in your facts:**
    * **actor:** The user or external system interacting with the system.
        * **Value Format:** `'actor_name'` (e.g., `'customer'`)
    * **goal:** The desired outcome or objective of an actor or the system.
        * **Value Format:** `'actor_or_system_goal_description'` (e.g., `'customer_spread_cost_over_time'`)
    * **object:** The data, entity, or resource manipulated or acted upon by the system.
        * **Value Format:** `'object_name'` (e.g., `'school_fee_payment'`)
    * **behavior:** The actions, operations, or processes performed by the system or an actor.
        * **Value Format:** `'actor_or_system_performs_action_on_object'` (e.g., `'customer_converts_school_fee_payment'`)
    * **system_functional_expectation:** What the system *must do* in terms of its functionality.
        * **Value Format:** `'system_component_performs_expected_behavior_on_object'` (e.g., `'system_enables_conversion_of_payments'`)
    * **system_non_functional_expectation:** Constraints or quality attributes (e.g., performance, security, usability), *only if directly stated as a system requirement.*
        * **Value Format:** `'system_component_has_attribute_value'` (e.g., `'system_has_response_time_less_than_1_second'`)
    * **relationship:** Any explicit relationship between extracted entities.
        * **Value Format:** `'entity1_relationship_type_entity2'` (e.g., `'order_includes_product'`)

    **Input:**
    {text}

    **Output Format:**
    Produce a series of Prolog-style logic facts, one per line. Each fact must end with a period (`.`).
    Strictly adhere to the predicate names (`requirement_fact`, `user_story_fact`, `acceptance_criteria_fact`), the specified `Key` atoms, and the `Value` formatting.

    **Strict Extraction Rules:**
    1.  **Explicitness and Logical Implication:** Only extract facts that are directly and explicitly stated in the input, or those that are unequivocally logically implied by the explicit statements. Avoid inferring beyond what is clearly presented.
    2.  **No Redundancy:** Each extracted fact must be unique. Do not repeat facts even if they are mentioned multiple times.
    3.  **No Interpretation or Summarization:** Do not interpret, summarize, or rephrase the facts. The `Key` must be one of the predefined semantic categories. The `Value` should be a descriptive, single-quoted atom derived from the original wording, ensuring it is lowercase with underscores (`_`) replacing spaces.
    4.  **No External Information:** Do not introduce any information or knowledge not contained within the provided input text.
    5.  **Strict Category Adherence:** Ensure each extracted fact accurately maps to one of the specified semantic categories (`Key`). If a piece of information does not fit, it should not be extracted.
    6.  **Granularity:** Extract facts at a granular level. Break down complex sentences into multiple atomic facts, ensuring each `Value` clearly encapsulates a single piece of information related to its `Key`.
    7.  **Atom Naming:** All predicate names (`requirement_fact`, etc.), `Key` atoms (e.g., `actor`, `goal`), and components within the `Value` (when constructing multi-word atoms) must be in lowercase. Use underscores (`_`) to separate words. All `Value` arguments must be enclosed in single quotes (e.g., `'customer_account'`).
    8.  **Fact Termination:** Every fact must end with a period (`.`).

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw text.
    """

prompt_for_checking_feedback_incorporation = """
You are an expert in requirement validation and structured fact extraction from Agile user stories.

    ## Context

    You are provided with:
    1. A **requirement** from a Business Requirements Document (BRD),
    2. A list of **Prolog-style extracted facts** from the requirement and the corresponding user stories with acceptance criteria,
    3. A set of **user stories and acceptance criteria** that attempt to capture the requirement.

    ---
    ### Requirement
    {inputs["requirement_text"]}

    ---
    ### Prolog-style extracted facts
    {inputs["facts_text"]}


    ---
    ### User Stories and Acceptance Criteria (JSON)
    {json.dumps(inputs["feedback_incorporated_user_story_text"], indent=2)}

    ---
    ### Task

    1. Compare the **requirement facts** with the facts represented in the **user stories and acceptance criteria**.
    2. Identify any **requirement facts that are missing or not semantically represented** in the user stories or acceptance criteria.
    3. Return **only the missing facts** in Prolog-style syntax. Use the following conventions:
    - `requirement(object, 'FR004', '...')`
    - `requirement(relationship, 'FR004', 'A', 'REL', 'B')`
    - `user_story(actor|goal|action, 'US-1', ...)`
    - `acceptance_criterion(system_state|system_action, 'AC-1', ...)`
    4. Ensure values are lowercase with underscores (`bus_fee` instead of `'Bus Fee'`).
    5. Do **not** repeat facts that are already present in the extracted facts list.
    6. Do **not** return explanations—just the new facts in this format:
        requirement(object, 'FR004', 'system').
        requirement(relationship, 'FR004', 'system', 'provide', 'option').

    Only return facts that are **missing or semantically unmatched** from the requirement and not represented in the 
    user stories or their acceptance criteria.

    If there are no facts that are **missing or semantically unmatched** return the message 
    "All requirement facts have been represented in either the user stories or acceptance criteria"

    IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
"""

prompt_for_feedback_incorporation = """
    You are an expert in software requirement engineering and agile user story refinement.

    Inputs:
    1. Requirement:
    {requirement_text}

    2. Extracted User Stories (JSON):
    {user_story_text}

    3. Validation Results (JSON):
    {validation_result_text}

    4. Extracted Facts (plaintext):
    {facts_text}

    Objective:
    Ensure that _all_ requirement facts appear in at least one user story or its acceptance criteria. If any fact is 
    missing (flagged as missing in Validation Results), modify the existing user stories—either the story text or 
    acceptance criteria—to include the missing fact. Do **not** add new stories unless absolutely necessary for coverage. 
    Preserve intent and scope of original stories.

    Instructions:
    • Identify which facts are missing according to validation results.
    • For each missing fact, integrate it into the most appropriate existing story or its acceptance criteria.
    • Avoid duplicating or inventing facts beyond what's needed.
    • Maintain the structure and metadata for each story: user story text, acceptance criteria, tshirt size, questions_for_po.
    • Output the **full** updated JSON with all original stories (modified as needed), matching this format exactly:

    [  
        {{  
            "requirement_id": "REQ‑XXX",  
            "requirement": "…",  
            "confidence_score": 0.Y,  
            "stories": [  
                {{  
                    "user_story": "As a …, I want to … so that …",  
                    "acceptance_criteria": [ "…" ],  
                    "tshirt_size": "S|M|L|XL",  
                    "questions_for_po": [ "…" ]  
                }},  
                … 
            ]  
        }}  
    ]

    IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).
    """