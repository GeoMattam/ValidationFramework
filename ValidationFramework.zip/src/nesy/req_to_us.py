from typing import List, Dict
import json
from utils.prompt_utils import extract_clean_json
from rich import print as rprint
from rich import print_json
from typing import Optional, Dict
import re

import os
from dotenv import load_dotenv

from prompts.nesy.nesy_prompt import * 
import utils.llm_invoke as llminvoke

# load .env file to environment
load_dotenv()

MODEL_INSTANCE = os.getenv('MODEL_INSTANCE')
MODEL_NAME = os.getenv('MODEL_NAME')
ROOT_PATH =  os.getenv('ROOT_PATH')

def extract_user_story(text: str):
    prompt = prompt_for_user_story.format(text=text)
    
    messages = [
        {"role": "system", "content": "You are an expert Business Analyst and System Architect."},
        {"role": "user", "content": prompt}
    ]

    # Initialize LLM client
    llm_client = llminvoke.llm_initialize(MODEL_INSTANCE)
    
    # Invoke LLM
    response = llm_client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages
    )
    
    # Extract content from LLM response
    response_content = response.choices[0].message.content.strip()
    
    return response_content

def extract_user_story_from_requirement(requirement: str) -> Dict:
    user_story = ""
    
    # Extract facts from requirements
    # req_facts = extract_facts("requirement", entry["requirement"])
    user_story = extract_clean_json(extract_user_story(requirement))

    return user_story

