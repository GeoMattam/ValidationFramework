import os
from dotenv import load_dotenv
from typing import Dict, List

from prompts.nesy.nesy_prompt import * 
from utils.prompt_utils import extract_clean_json
import utils.llm_invoke as llminvoke

# load .env file to environment
load_dotenv()

MODEL_INSTANCE = os.getenv('MODEL_INSTANCE')
MODEL_NAME = os.getenv('MODEL_NAME')
ROOT_PATH =  os.getenv('ROOT_PATH')

def preprocess_md_tool(inputs: Dict, lines_per_page=50) -> Dict:
    """
    Loads a .md file and preprocesses the md file to add linenumbers and page numbers. Saves it back as proprocessed md file
    """
    file_path = inputs["file_path"]
    numbered_brd = ""
    current_page = 1
    current_line_nr = 1

    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        for i, line in enumerate(lines):
            if i % lines_per_page == 0:
                numbered_brd += "".join(f"\n--- Page {current_page} ---\n")
                current_page += 1
            if line == "\n": # add line numbers to only lines with text else ignore and add as is
                numbered_brd += "".join(f"{line.strip()}")
            else:
                numbered_brd += "".join(f"[Line {current_line_nr:03}] {line.strip()}\n")
                current_line_nr += 1
                
    
    file_path = f"{ROOT_PATH}nesy/output/BRD_NGB_Preprocessed.md"
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(numbered_brd)

def load_md_tool(inputs: Dict) -> Dict:
    """
    Loads a .md file and returns its raw text.
    """
    file_path = inputs["file_path"]
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    return {"raw_text": text}

def extract_requirements(file_content: str):
    prompt = prompt_for_requirement_extraction.format(SRS=file_content)
    
    messages = [
        {"role": "system", "content": "You are an expert Business Analyst and System Architect."},
        {"role": "user", "content": prompt}
    ]

    # Initialize LLM client
    llm_client = llminvoke.llm_initialize(MODEL_INSTANCE)
    
    # Invoke LLM
    response = llm_client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages
    )
    
    # Extract content from LLM response
    response_content = response.choices[0].message.content.strip()
    
    return response_content

def extract_requirements_from_md(inputs: Dict):
    # Step 1: First get the requirement text in whole
    raw_text = inputs["raw_text"]

    requirements = extract_clean_json(extract_requirements(raw_text))

    return requirements