import os
from dotenv import load_dotenv
from typing import List, Dict
import json
from rich import print as rprint
from rich import print_json
from typing import Optional, Dict


from utils.prompt_utils import extract_clean_json
from utils.llm_invoke import llm_execution
from prompts.nesy.nesy_prompt import * 

# load .env file to environment
load_dotenv()

MODEL_INSTANCE = os.getenv('MODEL_INSTANCE')
MODEL_NAME = os.getenv('MODEL_NAME')
ROOT_PATH =  os.getenv('ROOT_PATH')

def load_file_content(file_path: str, key_value: str) -> Dict:
    """
    Loads a .md file and returns its raw text.
    """
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    return {key_value: text}

def incorporate_nesy_feedback(inputs: Dict) -> Dict:
    all_contents = {"requirement_text": inputs["requirement_text"]}

    all_contents.update(load_file_content(inputs["extracted_user_story"], key_value="user_story_text"))
    all_contents.update(load_file_content(inputs["extracted_facts"], key_value="facts_text"))
    all_contents.update(load_file_content(inputs["validation_result"],key_value="validation_result_text"))

    prompt = prompt_for_feedback_incorporation.format(all_contents)
    response_content = llm_execution(prompt)
    
    user_story = extract_clean_json(response_content)

    return user_story

def check_extracted_facts_with_feedback_incorporates(inputs: Dict) -> Dict:
    all_contents = {"requirement_text": inputs["requirement_text"]}

    all_contents.update(load_file_content(inputs["feedback_incorporated_user_story"],key_value="feedback_incorporated_user_story_text"))
    all_contents.update(load_file_content(inputs["extracted_facts"], key_value="facts_text"))

    prompt = prompt_for_checking_feedback_incorporation.format(all_contents)

    response_content = llm_execution(prompt)
    
    return response_content
