import os
from dotenv import load_dotenv
import json
from rich import print as rprint
from rich import print_json as jprint

from src.nesy.fact_extractor import extract_facts_for_entry
from src.nesy.req_to_us import extract_user_story_from_requirement
from src.nesy.requirement_extractor import load_md_tool, extract_requirements_from_md, preprocess_md_tool
from src.nesy.feedback_implementor import incorporate_nesy_feedback, check_extracted_facts_with_feedback_incorporates

from TheNeSyPackage.validate_experta import *
from src.nesy.symbolic_validator_semantic import *

OUTPUT = "prolog"

# load .env file to environment
load_dotenv()
ROOT_PATH =  os.getenv('ROOT_PATH')

def extract_facts(validated = False):
    rprint("[bold magenta] Output for REQ-001 [/bold magenta]")
    
    # read the content of the extracted user stories and convert to JSON for easy handling
    if validated:
        file_path = f"{ROOT_PATH}nesy/output/extracted_user_story_feedback_incorporated.json"
        with open(file_path, "r") as f:
            content = f.read()
    else:
        file_path = f"{ROOT_PATH}nesy/output/extracted_user_story.json"
        with open(file_path, "r") as f:
            content = f.read()

    requirements = json.loads(content)

    # Extract facts
    result = ""
    for req in requirements:
        result += extract_facts_for_entry(req)

    # print_json(json.dumps(result, indent=2))
    if OUTPUT == "prolog":
        if validated:
            file_path = f"{ROOT_PATH}nesy/output/extracted_facts_after_validation.txt"
            with open(file_path, "w") as f:
                f.write(result)                
        else:
            file_path = f"{ROOT_PATH}nesy/output/extracted_facts.txt"
            with open(file_path, "w") as f:
                f.write(result)
        
        rprint(f"[bold green]Extracted facts from requirement, user stories and acceptance criteria written to extracted_facts.txt [/bold green]")
    elif OUTPUT == "json":
        file_path = f"{ROOT_PATH}nesy/output/extracted_facts.json"
        with open(file_path, "w") as f:
            json.dump(result, f, indent=2)

        rprint(f"[bold green]Code summary written to output_extracted_facts.json [/bold green]")
    
def validate_facts_experta():
    # Validate
    engine = RequirementsValidatorV4()
    engine.reset()
    engine.run()

    # 1. Create a lookup map of all facts by their unique ID
    fact_lookup = {f['__factid__']: f for f in engine.facts.values()}

    # 2. Get the unique IDs of ALL requirement facts
    all_req_ids = {f['__factid__'] for f in fact_lookup.values() if isinstance(f, Requirement)}

    # 3. Get the unique IDs of the COVERED requirement facts
    covered_req_ids = {
        f['req_fact']['__factid__']
        for f in fact_lookup.values() if isinstance(f, CoveredRequirement)
    }

    # 4. Perform the set difference on the IDs - this is now 100% reliable
    uncovered_req_ids = all_req_ids - covered_req_ids

    # 5. Print the report using the lookup map for readable output

    print(f"--- Covered Requirements ({len(covered_req_ids)}) ---")
    if not covered_req_ids:
        print("None.")
    else:
        # Sort by the string representation of the looked-up fact
        sorted_covered = sorted([fact_lookup[fid] for fid in covered_req_ids], key=str)
        for req in sorted_covered:
             print(f"- {req}") # This now uses our __str__ method correctly

    print("\n" + f"--- Uncovered Requirements (Gaps) ({len(uncovered_req_ids)}) ---")
    if not uncovered_req_ids:
        print("None. All requirements have been covered!")
    else:
        # Sort by the string representation of the looked-up fact
        sorted_uncovered = sorted([fact_lookup[fid] for fid in uncovered_req_ids], key=str)
        for req in sorted_uncovered:
            print(f"- {req}") # This now uses our __str__ method correctly

    print("\n" + "="*50)

def validate_facts_semantically(validated = False):
    output = convert_facts_to_flat_json("FR010", validated)
    jprint(json.dumps(output, indent=2))
    
    fact_entry = output

    """ 
    # Example extracted facts from BRD, user story, and acceptance criteria
    fact_entry = {
        "requirement_id": "REQ-001",
        "facts": [
            # Requirements
            {"source": "requirement", "key": "object", "value": "school_fee_payment"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through online_banking"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through mobile_banking"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through ivr"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment can_be_paid_through e_form"},
            {"source": "requirement", "key": "relationship", "value": "e_form via contact_center_agent"},
            {"source": "requirement", "key": "relationship", "value": "school_fee_payment available_to customers_with_ngb_credit_cards"},

            # User story
            {"source": "user_story", "key": "actor", "value": "customer"},
            {"source": "user_story", "key": "goal", "value": "conveniently_pay_school_fees"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees online_banking"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees mobile_banking"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees ivr"},
            {"source": "user_story", "key": "action", "value": "customer pay school_fees e_form"},
            {"source": "user_story", "key": "action", "value": "contact_center_agent process e_form"},
            {"source": "user_story", "key": "action", "value": "customer use ngb_credit_card"},

            # Acceptance criteria
            {"source": "acceptance_criteria", "key": "system_action", "value": "system provide payment_confirmation"},
            {"source": "acceptance_criteria", "key": "system_action", "value": "system send payment_confirmation customer"},
        ]
    }
    """
    # Run semantic validation
    result = validate_facts(fact_entry)

    # Optional: Export to JSON file
    if validated:
        file_path = f"{ROOT_PATH}nesy/output/validation_result_after_feedback_incorporated.json"
        with open(file_path, "w") as f:
            json.dump(result, f, indent=1)
    else:
        file_path = f"{ROOT_PATH}nesy/output/validation_result.json"
        with open(file_path, "w") as f:
            json.dump(result, f, indent=1)

    print("\n📄 Validation summary exported to 'validation_result.json'")

def check_incorporated_feedback(requirement: str):
    inputs = {
        "requirement_text": requirement,
        "feedback_incorporated_user_story": "extracted_user_story_feedback_incorporated.json",
        "extracted_facts": "extracted_facts.txt",
    }
    result = check_extracted_facts_with_feedback_incorporates(inputs=inputs)
    rprint(f"[bold green]{result}[/bold green]")

def incorporate_feedback(requirement: str):
    inputs = {
        "requirement_text": requirement,
        "extracted_user_story": "extracted_user_story.json",
        "extracted_facts": "extracted_facts.txt",
        "validation_result": "validation_result.json"
    }
    result = incorporate_nesy_feedback(inputs=inputs)
    jprint(json.dumps(result, indent=2))

    file_path = f"{ROOT_PATH}nesy/output/extracted_user_story_feedback_incorporated.json"
    with open(file_path, "w") as f:
        json.dump(result, f, indent=2)

    rprint(f"[bold green]NeSy Feedback incorporated user stories written to to output_extracted_facts.json [/bold green]")

def extract_requirements(file_path: str, pre_process=False):
    # Extract requirements from the SRS / BRD .md file
    if pre_process: 
        preprocess_md_tool({"file_path": file_path})

    file_path = f"{ROOT_PATH}nesy/output/BRD_NGB_Preprocessed.md"
    result = load_md_tool({"file_path":file_path})
    requirements = extract_requirements_from_md({"raw_text": result["raw_text"]})
    
    file_path = f"{ROOT_PATH}nesy/output/extracted_requirements.json"
    with open(file_path, "w") as f:
        json.dump(requirements, f, indent=2)

    rprint(f"[bold green]Code summary written to output_extracted_facts.json [/bold green]")

def extract_us(text: str):
    # Extract facts
    result = extract_user_story_from_requirement(text)
    jprint(json.dumps(result, indent=2))

    file_path = f"{ROOT_PATH}nesy/output/extracted_user_story.json"
    with open(file_path, "w") as f:
        json.dump(result, f, indent=2)

    rprint(f"[bold green]User stories written to extracted_user_story.json [/bold green]")

def read_extracted_requirements():

    file_path = f"{ROOT_PATH}nesy/input/extracted_requirements.json"
    # read the content of the extracted user stories and convert to JSON for easy handling
    with open(file_path, "r") as f:
        content = f.read()

    extracted_requirements = json.loads(content)
    for entry in extracted_requirements:
        functional_requirements = entry["Functional Requirements"]
        rprint(functional_requirements)