import os
from dotenv import load_dotenv
from typing import List, Dict
from rich import print as rprint
from rich import print_json

from utils.prompt_utils import extract_clean_json
from prompts.nesy.nesy_prompt import *
from utils.llm_invoke import llm_execution

# load .env file to environment
load_dotenv()

MODEL_INSTANCE = os.getenv('MODEL_INSTANCE')
MODEL_NAME = os.getenv('MODEL_NAME')
ROOT_PATH =  os.getenv('ROOT_PATH')


def extract_prolog_style_facts(input_type: str, text: str):
    prompt = prompt_for_facts.format(input_type=input_type, text=text)
    
    response_content = llm_execution(prompt)
    
    return response_content

def extract_facts(input_type: str, text: str) -> List[Dict[str, str]]:
    prompt = prompt_for_facts.format(input_type, text)
    response_content = llm_execution(prompt)

    try:
        llm_results = extract_clean_json(response_content)
    except Exception as e:
        llm_results = []
    
    return llm_results

def extract_facts_for_entry(entry: Dict) -> Dict:
    all_facts = []
    prolog_facts = ""
    
    # Extract facts from requirements
    # req_facts = extract_facts("requirement", entry["requirement"])
    req_facts = extract_prolog_style_facts("requirement", entry["requirement"])
    prolog_facts += req_facts
    # all_facts.extend([{"source": "requirement", **f} for f in req_facts]) # use this if JSON

    # Extract facts from user story and acceptance criteria for each user story
    # story_facts = extract_facts("user story", entry["user_story"])
    for story in entry.get("stories", []):
        story_facts = extract_prolog_style_facts("user story", story["user_story"])
        prolog_facts += story_facts
        # all_facts.extend([{"source": "user_story", **f} for f in story_facts]) # use this if JSON

        # Extract from each acceptance criterion
        for ac in story.get("acceptance_criteria", []):
            # ac_facts = extract_facts("acceptance criteria", ac)
            ac_facts = extract_prolog_style_facts("acceptance criteria", ac)
            prolog_facts += ac_facts
            # all_facts.extend([{"source": "acceptance_criteria", **f} for f in ac_facts])  # grouped under user story facts

    """ return {
        "requirement_id": entry["requirement_id"],
        "facts": all_facts
    } """ # use this if working with JSON

    return prolog_facts

