import os
from trulens.core import Feedback, TruSession
from trulens.apps.basic import TruBasicApp
from trulens.providers.litellm import LiteLLM

# Set your API key
os.environ["GOOGLE_API_KEY"] = "AIzaSyAlpg24hVWAyD5lXZRTMYGbk7IseZE5CjI"

# Initialize session
session = TruSession()

# Initialize Gemini provider
gemini_provider = LiteLLM(model_engine="gemini/gemini-2.5-flash")

# Define feedback functions with correct syntax
f_relevance = Feedback(
    gemini_provider.relevance_with_cot_reasons,
    name="Answer Relevance"
).on_input_output()

f_coherence = Feedback(
    gemini_provider.coherence_with_cot_reasons,
    name="Coherence"
).on_output()

# Create a simple text-to-text function
def gemini_text_to_text(prompt: str) -> str:
    """Simple function that takes text input and returns text output"""
    import google.generativeai as genai
    genai.configure(api_key=os.environ["GOOGLE_API_KEY"])
    model = genai.GenerativeModel('gemini-2.5-flash')
    response = model.generate_content(prompt)
    return response.text

# Wrap with TruBasicApp - using two feedback functions that work with basic apps
tru_app = TruBasicApp(
    text_to_text=gemini_text_to_text,
    app_id="gemini_demo_simple",
    feedbacks=[f_relevance, f_coherence]  # Only using feedbacks that don't require context
)

# Test prompts
test_prompts = [
    "What is the capital of France?",
    "Explain photosynthesis in simple terms.",
    "What are the benefits of renewable energy?"
]

print("🚀 Starting TruLens evaluation with Gemini-2.5-Flash...")

# Run evaluations
for prompt in test_prompts:
    with tru_app as recording:
        response = tru_app.app(prompt)
        print(f"\nPrompt: {prompt}")
        print(f"Response: {response}")

print("\n✅ Evaluation completed!")

# View results
try:
    leaderboard = session.get_leaderboard()
    print("\n📊 Results:")
    print(leaderboard)
except Exception as e:
    print(f"Note: Leaderboard display error (this is normal): {e}")

# Launch dashboard
from trulens.dashboard import run_dashboard
run_dashboard(session)
