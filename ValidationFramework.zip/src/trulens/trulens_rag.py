# gemini_rag_trulens.py
# ------------------------------------------------------------
# RAG (LangChain) + Gemini 2.5 Flash + TruLens (OTEL-safe, new API)
# - No Lens selectors; only dict/shortcut selectors (.on_input, .on_output)
# - Feedback fns are top-level & serializable; param names match selectors
# ------------------------------------------------------------

import os
import re
import sys
from typing import List, Any

# ---------- LangChain / Gemini ----------
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
from langchain.vectorstores import Chroma
from langchain.prompts import ChatPromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.retrieval import create_retrieval_chain

# ---------- TruLens (new namespaces) ----------
from trulens.core import Tru, Feedback
from trulens.apps.langchain import TruChain

# ---------- Gemini Judge ----------
import google.generativeai as genai

# ===================== Config =====================

GEMINI_CHAT_MODEL = os.getenv("GEMINI_CHAT_MODEL", "gemini-2.5-flash")
GEMINI_JUDGE_MODEL = os.getenv("GEMINI_JUDGE_MODEL", "gemini-1.5-pro")
EMBED_MODEL = os.getenv("GEMBED_MODEL", "models/text-embedding-004")  # fallback: "models/embedding-001"

# Global judge instance for serialization-friendly, top-level feedback fns
JUDGE = None


# ===================== Utilities =====================

def require_env(var: str):
    if not os.getenv(var):
        print(f"[ERROR] Missing environment variable {var}. Please set it and retry.", file=sys.stderr)
        sys.exit(1)


def configure_gemini():
    require_env("GOOGLE_API_KEY")
    genai.configure(api_key=os.environ["GOOGLE_API_KEY"])


def init_gemini_judge(model_name: str = GEMINI_JUDGE_MODEL):
    global JUDGE
    JUDGE = genai.GenerativeModel(model_name)


def build_corpus() -> List[Document]:
    # Replace with your own real loader (files, DB, web, etc.)
    return [
        Document(page_content="The iPhone was first released in 2007 by Apple."),
        Document(page_content="TruLens is an open-source framework for evaluating LLM and RAG applications."),
        Document(page_content="NeMo Guardrails helps enforce safety and policy constraints in LLM apps.")
    ]


def normalize_context(ctx: Any) -> str:
    """
    Convert typical retrieval outputs (list of Documents / strings / dicts)
    into a single text blob for the judge.
    """
    if ctx is None:
        return ""
    if isinstance(ctx, str):
        return ctx
    if isinstance(ctx, (list, tuple)):
        parts = []
        for c in ctx:
            if isinstance(c, Document):
                parts.append(c.page_content or "")
            elif isinstance(c, dict) and "page_content" in c:
                parts.append(str(c.get("page_content", "")))
            else:
                parts.append(str(c))
        return "\n\n".join(p for p in parts if p)
    # Fallback for unexpected types:
    return str(ctx)


# ===================== Gemini-as-judge helpers =====================

_FLOAT01_RE = re.compile(r"(0(?:\.\d+)?|1(?:\.0+)?)")

def _extract_01(text: str) -> float:
    m = _FLOAT01_RE.search((text or "").strip())
    if not m:
        return 0.0
    try:
        v = float(m.group(1))
    except ValueError:
        return 0.0
    return max(0.0, min(1.0, v))


def _score_with_gemini(prompt: str) -> float:
    # JUDGE must be initialized via init_gemini_judge(...)
    resp = JUDGE.generate_content(prompt)
    text = getattr(resp, "text", "") or ""
    return _extract_01(text)


# ===================== Feedback functions (TOP-LEVEL) =====================
# IMPORTANT: parameter names MUST MATCH selectors used below:
# - .on_input()             -> param name "input"
# - .on_output("context")   -> param name "context"
# - .on_output("answer")    -> param name "answer"

def groundedness(context, answer) -> float:
    """
    Score in [0,1] how well ANSWER is supported strictly by CONTEXT.
    """
    context_text = normalize_context(context)
    prompt = f"""
Return a single number in [0,1] for how well ANSWER is supported strictly by CONTEXT.
1.0 = fully supported; 0.0 = unsupported/contradictory.
Return ONLY the number.

CONTEXT:
{context_text}

ANSWER:
{answer}
"""
    return _score_with_gemini(prompt)


def retrieval_relevance(input, context) -> float:
    """
    Score in [0,1] how relevant CONTEXT is to QUESTION (from input).
    """
    question = input.get("question") if isinstance(input, dict) else str(input)
    context_text = normalize_context(context)
    prompt = f"""
Return a single number in [0,1] for how relevant CONTEXT is to QUESTION.
1.0 = highly relevant; 0.0 = irrelevant.
Return ONLY the number.

QUESTION:
{question}

CONTEXT:
{context_text}
"""
    return _score_with_gemini(prompt)


def answer_relevance(input, answer) -> float:
    """
    Score in [0,1] how relevant ANSWER is to QUESTION (from input).
    """
    question = input.get("question") if isinstance(input, dict) else str(input)
    prompt = f"""
Return a single number in [0,1] for how relevant ANSWER is to QUESTION.
1.0 = highly relevant; 0.0 = irrelevant.
Return ONLY the number.

QUESTION:
{question}

ANSWER:
{answer}
"""
    return _score_with_gemini(prompt)


# ===================== Build RAG =====================

def build_rag_chain():
    # 1) Corpus -> chunks
    docs = build_corpus()
    chunks = RecursiveCharacterTextSplitter(chunk_size=250, chunk_overlap=40).split_documents(docs)

    # 2) Embeddings + Vector store
    embeddings = GoogleGenerativeAIEmbeddings(model=EMBED_MODEL)
    vs = Chroma.from_documents(chunks, embeddings)
    retriever = vs.as_retriever(search_kwargs={"k": 3})

    # 3) Prompt + Gemini LLM
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a helpful assistant. Use ONLY the provided context to answer. "
         "If the answer is not in the context, say you don't know."),
        ("system", "Context:\n{context}"),
        ("human", "{question}")
    ])

    llm = ChatGoogleGenerativeAI(model=GEMINI_CHAT_MODEL)
    qa_chain = create_stuff_documents_chain(llm, prompt)

    # 4) Retrieval-augmented chain
    # Output typically includes keys: 'answer' and 'context'
    return create_retrieval_chain(retriever, qa_chain)


# ===================== TruLens instrumentation (OTEL-safe) =====================

def instrument_with_trulens(rag_chain):
    # Initialize local sqlite (trulens.db) in CWD; OTEL works with dict selectors below.
    _ = Tru()

    # Build Feedbacks using ONLY dict/shortcut selectors
    f_grounded = (
        Feedback(groundedness, name="groundedness_gemini")
            .on_output("context")   # -> param "context"
            .on_output("answer")    # -> param "answer"
    )

    f_ret_rel = (
        Feedback(retrieval_relevance, name="retrieval_relevance_gemini")
            .on_input()             # -> param "input"
            .on_output("context")   # -> param "context"
    )

    f_ans_rel = (
        Feedback(answer_relevance, name="answer_relevance_gemini")
            .on_input()             # -> param "input"
            .on_output("answer")    # -> param "answer"
    )

    # Attach feedbacks in the constructor (new API). Omit app_id/app_name to avoid signature drift.
    app = TruChain(
        app=rag_chain,
        feedbacks=[f_grounded, f_ret_rel, f_ans_rel],
    )
    return app


# ===================== Eval harness =====================

def run_eval(app: TruChain):
    eval_queries = [
        {"question": "When was the first iPhone released?"},
        {"question": "What is TruLens used for?"},
        {"question": "What does NeMo Guardrails do?"},
        {"question": "Who won the 1999 Cricket World Cup?"}  # out-of-context for our toy data
    ]

    for q in eval_queries:
        rec = app.run(q)
        # Friendly print; structure can vary slightly by LC/TruLens versions:
        try:
            out = rec["output"]
            ans = out.get("answer")
            ctx = out.get("context", [])
            print(f"Q: {q['question']}")
            print(f"A: {ans}")
            print(f"Retrieved: {len(ctx) if isinstance(ctx, (list, tuple)) else ('1 blob' if ctx else 0)}")
            print("-" * 60)
        except Exception as e:
            print("Error:",str(e))
            print(f"Ran: {q}")

    print("\n[OK] Logged runs with feedback to TruLens.")
    print("To view results, run in another terminal:")
    print("  trulens-eval dashboard")
    print("Open the printed URL to explore runs & scores.")


# ===================== Main =====================

def main():
    configure_gemini()
    init_gemini_judge(GEMINI_JUDGE_MODEL)

    print(f"[Info] Building RAG with chat model: {GEMINI_CHAT_MODEL}")
    rag = build_rag_chain()

    print("[Info] Instrumenting RAG with TruLens (OTEL-safe selectors)…")
    app = instrument_with_trulens(rag)

    print("[Info] Running eval set…")
    run_eval(app)


if __name__ == "__main__":
    main()