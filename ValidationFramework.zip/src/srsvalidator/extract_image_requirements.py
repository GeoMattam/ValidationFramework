import zipfile
import fitz  # PyMuPDF
import io
from PIL import Image
import pytesseract
from docx import Document

def extract_image_bytes_from_docx(docx_path):
    doc = Document(docx_path)
    rels = doc.part._rels
    image_bytes_list = []

    for rel in rels.values():
        if "image" in rel.reltype:
            image_bytes = rel.target_part.blob
            image_bytes_list.append(image_bytes)

    return image_bytes_list

def extract_image_bytes_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    images = []

    for i, page in enumerate(doc):
        image_list = page.get_images(full=True)
        for img in image_list:
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            images.append(image_bytes)

    return images

def run_ocr_on_images(images):
    texts = []
    for img_bytes in images:
        image = Image.open(io.BytesIO(img_bytes))
        text = pytesseract.image_to_string(image)
        texts.append(text)
    combined_texts = "\n".join(texts)
    return combined_texts

def write_to_md(file_path,response_content):
    # Save the response to a Markdown file
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(response_content)


if __name__ == "__main__":
    docx_path = "C:/Solutions/ValidationFramework/includes/srs_validator/input/CQure_Insurance_SRS_30-Aug-2005.docx"
    lst_images = extract_image_bytes_from_docx(docx_path)
    response_content = run_ocr_on_images(lst_images)
    file_path = "C:/Solutions/ValidationFramework/includes/srs_validator/output/CQure_Insurance_SRS_imageContent.md"
    write_to_md(file_path,response_content)