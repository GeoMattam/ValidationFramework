import os
from dotenv import load_dotenv
import json
import yaml
import time
from typing import Dict, List
from langchain_community.agent_toolkits import FileManagementToolkit

from utils.logging_config import app_logger
import utils.llm_invoke as llminvoke
import utils.unique_key as uniquekey
import utils.load_yaml as load_yaml
import utils.heading_with_content as heading_with_content
from prompts.srsvalidator.srs_validator_prompts import *


file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file"]).get_tools()
read_file, write_file = file_stores


# load .env file to environment
load_dotenv()
ROOT_PATH =  os.getenv('ROOT_PATH')

def extract_requirements_json(response_content: str) -> Dict[str, List[Dict]]:
    app_logger.info("Processing JSON response content")
    if not response_content or not isinstance(response_content, str):
        app_logger.error("Invalid or empty response content provided")
        return {
            "functional": [],
            "non_functional": [],
            "business_rules": [],
            "ambiguous": [],
            "observations": [],
            "combined": {}
        }

    # Remove markdown code fences if present
    if response_content.startswith("```json") and response_content.endswith("```"):
        response_content = response_content[7:-3].strip()
        app_logger.info("Removed markdown JSON code fences from response")
    elif response_content.startswith("```") and response_content.endswith("```"):
        response_content = response_content[3:-3].strip()
        app_logger.info("Removed markdown code fences from response")

    # Initialize output lists
    functional = []
    non_functional = []
    business_rules = []
    ambiguous = []
    observations = []

    # Parse response as JSON
    try:
        parsed_response = json.loads(response_content)
        app_logger.info("Successfully parsed LLM response as JSON")

        # Extract requirements from JSON
        functional = parsed_response.get("Functional Requirements", [])
        non_functional = parsed_response.get("Non-Functional Requirements", [])
        business_rules = parsed_response.get("Business Rules", [])
        ambiguous = parsed_response.get("Ambiguous or Subjective Requirements", [])
        observations = parsed_response.get("Other_Observations", [])

        # Ensure lists are not None
        functional = functional if functional else []
        non_functional = non_functional if non_functional else []
        business_rules = business_rules if business_rules else []
        ambiguous = ambiguous if ambiguous else []
        observations = observations if observations else []

    except json.JSONDecodeError as e:
        app_logger.error(f"Failed to parse LLM response as JSON: {str(e)}")
        # Fallback: Attempt to parse as line-based JSON
        current_section = None
        lines = response_content.split("\n")
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if line.startswith("**Functional Requirements**"):
                current_section = "functional"
                app_logger.debug("Parsing Functional Requirements")
            elif line.startswith("**Non-Functional Requirements**"):
                current_section = "non_functional"
                app_logger.debug("Parsing Non-Functional Requirements")
            elif line.startswith("**Business Rules**"):
                current_section = "business_rules"
                app_logger.debug("Parsing Business Rules")
            elif line.startswith("**Ambiguous or Subjective Requirements**"):
                current_section = "ambiguous"
                app_logger.debug("Parsing Ambiguous Requirements")
            elif line.startswith("**Other_Observations**"):
                current_section = "observations"
                app_logger.debug("Parsing Other Observations")
            elif line.startswith("[") and line.endswith("]"):
                try:
                    item = json.loads(line.replace("'", '"'))
                    if current_section == "functional":
                        functional.append(item)
                    elif current_section == "non_functional":
                        non_functional.append(item)
                    elif current_section == "business_rules":
                        business_rules.append(item)
                    elif current_section == "ambiguous":
                        ambiguous.append(item)
                    elif current_section == "observations":
                        observations.append(item)
                except json.JSONDecodeError as e:
                    app_logger.warning(f"Failed to parse JSON line: {line}, Error: {str(e)}")
                    continue

    # Preserve original JSON data for combined attribute
    combined = parsed_response if isinstance(parsed_response, dict) else {}

    result = {
        "functional": functional,
        "non_functional": non_functional,
        "business_rules": business_rules,
        "ambiguous": ambiguous,
        "observations": observations,
        "combined": combined
    }
    app_logger.info(f"JSON Extraction completed. Functional: {len(functional)}, Non-Functional: {len(non_functional)}, Business Rules: {len(business_rules)}, Ambiguous: {len(ambiguous)}, Observations: {len(observations)}")
    return result

def extract_requirements_yaml(response_content: str) -> Dict[str, List[Dict]]:
    app_logger.info("Processing YAML response content")
    if not response_content or not isinstance(response_content, str):
        app_logger.error("Invalid or empty response content provided")
        return {
            "functional": [],
            "non_functional": [],
            "business_rules": [],
            "ambiguous": [],
            "observations": [],
            "combined": ""
        }

    # Remove markdown code fences if present and store raw YAML for combined
    combined = response_content
    if response_content.startswith("```yaml") and response_content.endswith("```"):
        combined = response_content[7:-3].strip()
        response_content = response_content[7:-3].strip()
        app_logger.info("Removed markdown YAML code fences from response")
    elif response_content.startswith("```") and response_content.endswith("```"):
        combined = response_content[3:-3].strip()
        response_content = response_content[3:-3].strip()
        app_logger.info("Removed markdown code fences from response")

    # Initialize output lists
    functional = []
    non_functional = []
    business_rules = []
    ambiguous = []
    observations = []

    # Parse response as YAML
    try:
        parsed_response = yaml.safe_load(response_content)
        app_logger.info("Successfully parsed LLM response as YAML")

        # Extract requirements from parsed YAML
        functional = parsed_response.get("Functional Requirements", [])
        non_functional = parsed_response.get("Non-Functional Requirements", [])
        business_rules = parsed_response.get("Business Rules", [])
        ambiguous = parsed_response.get("Ambiguous or Subjective Requirements", [])
        observations = parsed_response.get("Other_Observations", [])

        # Ensure lists are not None
        functional = functional if functional else []
        non_functional = non_functional if non_functional else []
        business_rules = business_rules if business_rules else []
        ambiguous = ambiguous if ambiguous else []
        observations = observations if observations else []

    except yaml.YAMLError as e:
        app_logger.error(f"Failed to parse LLM response as YAML: {str(e)}")
        return {
            "functional": [],
            "non_functional": [],
            "business_rules": [],
            "ambiguous": [],
            "observations": [],
            "combined": combined
        }

    result = {
        "functional": functional,
        "non_functional": non_functional,
        "business_rules": business_rules,
        "ambiguous": ambiguous,
        "observations": observations,
        "combined": combined
    }
    app_logger.info(f"YAML Extraction completed. Functional: {len(functional)}, Non-Functional: {len(non_functional)}, Business Rules: {len(business_rules)}, Ambiguous: {len(ambiguous)}, Observations: {len(observations)}")
    return result

def split_text_into_chunks(text, chunk_size=5000):
    return [text[i:i + chunk_size] for i in range(0, len(text), chunk_size)]

def extract_requirements(srs_content, output_format) :
    myuuid = uniquekey.generate_uniquekey()
    app_logger.info("Starting requirement extraction for SRS content")
    if not srs_content or not isinstance(srs_content, str):
        app_logger.error("Invalid or empty SRS content provided")
        return {
            "functional": [],
            "non_functional": [],
            "business_rules": [],
            "ambiguous": [],
            "observations": [],
            "combined": ""
        }
    try:
        MODEL_INSTANCE = os.getenv('MODEL_INSTANCE')
        MODEL_NAME = os.getenv('MODEL_NAME')

        # Initialize LLM client
        llm_client = llminvoke.llm_initialize(MODEL_INSTANCE)
        app_logger.info("Initialized LLM client")

        #srs_chunks = split_text_into_chunks(srs_content, chunk_size=20000)
        doc_path = "C:/Solutions/ValidationFramework/includes/srs_validator/input/CQure_Insurance_SRS_Set1.docx"
        total_heading = heading_with_content.extract_number_heading_with_content(doc_path)
        
        additional_context = heading_with_content.filter_by_top_level(total_heading, '1')
        additional_context = additional_context + heading_with_content.filter_by_top_level(total_heading, '2')
        additional_context = additional_context + heading_with_content.filter_by_top_level(total_heading, '5')
    
        list_of_requirements = heading_with_content.filter_by_range(total_heading, '3.5', '3.14')

        results = []
        for requirement in list_of_requirements:
            for key, specific_requirement in requirement.items():
                app_logger.info(f"Processed Heading:{key}")
                #for idx, specific_requirement in enumerate(specific_requirements, start=1):
                # Prepare messages for LLM
                
                if output_format == "YAML":
                    app_logger.info("Inside YAML")
                    file_path = f"{ROOT_PATH}yaml/requirements.yaml"
                    yaml_data = load_yaml.load_yaml_file(file_path)        
                    actual_prompt = srs_extract_additional_comments_objective_YAML_plain #srs_extract_additional_comments_objective_1_YAML 
                    prompt = actual_prompt.format(specific_requirement=specific_requirement,additional_context=additional_context, YAML=yaml_data)
                else:
                    actual_prompt = srs_extract_additional_comments_objective_1
                    prompt = actual_prompt.format(specific_requirement=specific_requirement)

                messages = [
                    {"role": "system", "content": "You are an expert Business Analyst and System Architect."},
                    {"role": "user", "content": prompt}
                ]
                
                # Invoke LLM
                response = llm_client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=messages
                )
                
                # Extract content from LLM response
                response_content = response.choices[0].message.content.strip()
                app_logger.info("Received LLM response")
                
                idx = str(key).replace(".","_")
                file_path = f"{ROOT_PATH}srs_validator/output/{myuuid}/extract_requirements_{idx}.{output_format}"
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                write_file.invoke({"file_path": file_path, "text": response_content})

                #results.append(response_content)
                time.sleep(600)
            
        #response_content = "\n".join(results)
        #file_path = f"{ROOT_PATH}srs_validator/output/{myuuid}/extract_requirements.{output_format}"
        #os.makedirs(os.path.dirname(file_path), exist_ok=True)
        #write_file.invoke({"file_path": file_path, "text": response_content})

        # Detect format based on code fences
        if response_content.startswith("```json"):
            app_logger.info("Detected JSON format in LLM response")
            return extract_requirements_json(response_content)
        elif response_content.startswith("```yaml"):
            app_logger.info("Detected YAML format in LLM response")
            return extract_requirements_yaml(response_content)
        else:
            # Default to JSON if no specific code fence is detected
            app_logger.info("No specific code fence detected, defaulting to JSON")
            return extract_requirements_json(response_content)

    except Exception as e:
        app_logger.error(f"Failed to extract requirements: {str(e)}")
        return {
            "functional": [],
            "non_functional": [],
            "business_rules": [],
            "ambiguous": [],
            "observations": [],
            "combined": ""
        }