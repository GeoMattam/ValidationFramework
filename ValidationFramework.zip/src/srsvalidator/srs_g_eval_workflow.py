import os
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage
from langgraph.types import Command

from src.srsvalidator.srs_g_eval_node import State, g_eval, human_approval, update_srs, update_srs_manual, conclude, is_approved
from utils.normalize_human_msg import normalize_to_human_message_content

ROOT_PATH = os.getenv('ROOT_PATH', '')

_memory = MemorySaver()

def initialize_workflow(is_manual=False):
    workflow = StateGraph(State)

    workflow.add_node("G-Eval", g_eval)
    workflow.add_node("Human Approval", human_approval)
    workflow.add_node("Update SRS", update_srs_manual if is_manual else update_srs)
    workflow.add_node("Conclude", conclude)

    workflow.add_edge(START, "G-Eval")
    workflow.add_edge("G-Eval", "Human Approval")
    workflow.add_edge("Update SRS", "G-Eval")
    workflow.add_conditional_edges(
        "Human Approval",
        is_approved,
        {"approved": "Conclude", "enhance": "Update SRS"}
    )
    workflow.add_edge("Conclude", END)

    graph = workflow.compile(checkpointer=_memory)
    print("Workflow initialized and compiled.")
    return graph

def run_workflow_step(graph, srs_content, extract_requirements, uuid, iteration, output_format,feedback=None):
    thread = {"configurable": {"thread_id": uuid}}

    print(f"Running workflow step with feedback: {feedback}")

    normalized_content = normalize_to_human_message_content(extract_requirements)
    if feedback:
        # Resume the workflow with the feedback
        output_stream = graph.stream(Command(resume=feedback), config=thread, stream_mode="updates")
    else:
        # Initial run
        initial_state = {
            "messages": [HumanMessage(content="Run G-Evaluation")],
            "srs": [HumanMessage(content=srs_content)],
            "extracted_requirements": [HumanMessage(content=normalized_content)],
            "uuid": uuid,
            "iteration": iteration,
            "output_format":output_format,
            "feedback": ""
        }
        print("Initial state:", initial_state)
        output_stream = graph.stream(initial_state, config=thread, stream_mode="updates")

    last_non_interrupt_output = {}
    interrupt_info = None
    for s in output_stream:
        print("Stream output:", s)
        if '__interrupt__' in s:
            interrupt_info = s['__interrupt__']
            break
        last_non_interrupt_output.update(s)

    print("Last non-interrupt output:", last_non_interrupt_output)
    print("Interrupt info:", interrupt_info)
    return last_non_interrupt_output, interrupt_info