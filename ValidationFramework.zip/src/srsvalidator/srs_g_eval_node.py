import json
import os
import re
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from langchain_core.messages import HumanMessage, AIMessage
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt, Command

# TODO: Uncomment when using actual extract_requirements
from src.srsvalidator.extract_requirements import extract_requirements
# from src.srsvalidator.extract_requirements_dummy import extract_requirements
import utils.llm_invoke as llminvoke
from prompts.srsvalidator.srs_validator_prompts import G_Eval_style_prompt_SRS
from utils.normalize_human_msg import normalize_to_human_message_content
from utils.parse_human_msg import human_msg_to_json_yaml

ROOT_PATH = os.getenv('ROOT_PATH', '')
file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file"]).get_tools()
read_file, write_file = file_stores

MODEL_INSTANCE = os.getenv('MODEL_INSTANCE')
MODEL_NAME = os.getenv('MODEL_NAME')

llm_client = llminvoke.llm_initialize(MODEL_INSTANCE)

class State(TypedDict):
    messages: list
    srs: list
    extracted_requirements: list
    uuid: str
    iteration: int
    output_format: str
    feedback: str
    

def g_eval(state: State):
    srs = state['srs'][-1].content
    extracted_requirements = state['extracted_requirements'][-1].content
    uuid = state['uuid']
    iteration = state['iteration']

    parsed_extracted_requirements = human_msg_to_json_yaml(extracted_requirements)
    combined_reqs = parsed_extracted_requirements["combined"]

    prompt = G_Eval_style_prompt_SRS.format(srs=srs, extracted_requirements=combined_reqs)
    messages = [
        {"role": "system", "content": "You are an expert Business Analyst and System Architect."},
        {"role": "user", "content": prompt}
    ]

    # Call the LLM
    response = llm_client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages
    )
    result = response.choices[0].message.content

    # Extract the JSON portion using regex
    json_pattern = r'\{[\s\S]*\}'
    match = re.search(json_pattern, result, re.DOTALL)
    if not match:
        print(f"Invalid response from LLM, no JSON found: {result}")
        raise ValueError("LLM response does not contain a valid JSON object")

    json_str = match.group(0)

    # Remove Markdown code fences if present
    json_str = re.sub(r'^```json\n|\n```$', '', json_str, re.MULTILINE).strip()

    # Validate that the extracted result is valid JSON
    try:
        json.loads(json_str)
    except json.JSONDecodeError as e:
        print(f"Invalid JSON from LLM: {json_str}")
        raise ValueError(f"LLM returned invalid JSON: {str(e)}")

    print(f"G-Eval node running, result:\n{json_str}")

    return {
        "messages": state['messages'] + [AIMessage(content=json_str)],
        "uuid": uuid,
        "iteration": iteration,
        "srs": state['srs'],
        "extracted_requirements": state['extracted_requirements'],
        "feedback": state.get('feedback', '')
    }

def human_approval(state: State):
    uuid = state['uuid']
    iteration = state['iteration']
    print("Human approval node: Initial state:", {
        "messages": [m.content for m in state['messages']],
        "uuid": uuid,
        "iteration": iteration,
        "srs": [m.content for m in state['srs']],
        "extracted_requirements": [m.content for m in state['extracted_requirements']],
        "feedback": state.get('feedback', '')
    })

    feedback = interrupt("Enter the feedback:")
    print(f"Received feedback: {feedback}")

    # Append the feedback as a HumanMessage to the messages list
    final_state = {
        "messages": state['messages'] + [HumanMessage(content=f"Feedback received: {feedback}")],
        "feedback": feedback,
        "uuid": uuid,
        "iteration": iteration,
        "srs": state['srs'],
        "extracted_requirements": state['extracted_requirements']
    }

    print("Human approval node: Final state returned:", {
        "messages": [m.content for m in final_state['messages']],
        "uuid": uuid,
        "iteration": iteration,
        "srs": [m.content for m in final_state['srs']],
        "extracted_requirements": [m.content for m in final_state['extracted_requirements']],
        "feedback": feedback
    })

    return final_state

def update_srs(state: State):
    srs = state['srs'][-1].content
    feedback = state['feedback']
    uuid = state['uuid']
    iteration = state['iteration']
    output_format = state['output_format']

    messages = [
        {"role": "system", "content": "You are an expert Business Analyst. Update the SRS content based on the provided feedback."},
        {"role": "user", "content": f"Original SRS:\n{srs}\n\nFeedback:\n{feedback}\n\nUpdate the SRS content to incorporate the feedback."}
    ]

    response = llm_client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages
    )

    updated_srs = response.choices[0].message.content
    print(f"Updated SRS content:\n{updated_srs}")

    extracted_files = extract_requirements(updated_srs,output_format)

    normalized_content = normalize_to_human_message_content(extracted_files)

    return {
        "srs": [HumanMessage(content=updated_srs)],
        "extracted_requirements": [HumanMessage(content=normalized_content)],
        "iteration": iteration + 1,
        "uuid": uuid,
        "messages": state['messages'] + [HumanMessage(content="Updated SRS and re-extracted requirements")],
        "feedback": ""
    }

def update_srs_manual(state: State):
    feedback = state['feedback']
    uuid = state['uuid']
    iteration = state['iteration']
    output_format = state['output_format']

    # Feedback is expected to be a file object from Streamlit
    try:
        updated_srs = feedback
    except Exception as e:
        print(f"Error decoding uploaded SRS file: {str(e)}")
        raise ValueError("Failed to decode uploaded SRS file")

    print(f"Manually updated SRS content:\n{updated_srs}")

    extracted_files = extract_requirements(updated_srs,output_format)

    normalized_content = normalize_to_human_message_content(extracted_files)

    return {
        "srs": [HumanMessage(content=updated_srs)],
        "extracted_requirements": [HumanMessage(content=normalized_content)],
        "iteration": iteration + 1,
        "uuid": uuid,
        "messages": state['messages'] + [HumanMessage(content="Manually updated SRS and re-extracted requirements")],
        "feedback": ""
    }

def conclude(state: State):
    uuid = state['uuid']
    srs_content = state['srs'][-1].content
    g_eval_result = state['messages'][-2].content if len(state['messages']) >= 2 else "No G-Eval result found."

    file_name_srs = f"{ROOT_PATH}srs_validator/output/updated_srs/{uuid}/srs_freezed.md"
    os.makedirs(os.path.dirname(file_name_srs), exist_ok=True)
    write_file.invoke({"file_path": file_name_srs, "text": srs_content})

    print(f"Workflow concluded. Final SRS saved at {file_name_srs}")

    return {
        "messages": [HumanMessage(content="G-Evaluation completed and files saved.")],
        "uuid": uuid,
        "iteration": state['iteration'],
        "srs": state['srs'],
        "extracted_requirements": state['extracted_requirements'],
        "feedback": state.get('feedback', '')
    }

def is_approved(state: State):
    feedback = state.get('feedback', '')
    print(f"Checking approval status on feedback: '{feedback}'")
    if isinstance(feedback, str) and feedback.lower() in ("approved", "approve"):
        return "approved"
    return "enhance"